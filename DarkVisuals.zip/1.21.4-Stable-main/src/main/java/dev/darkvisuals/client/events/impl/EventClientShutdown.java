package dev.darkvisuals.client.events.impl;

import dev.darkvisuals.client.events.Event;

public class EventClientShutdown extends Event {
    // Событие вызывается при выключении клиента
} 