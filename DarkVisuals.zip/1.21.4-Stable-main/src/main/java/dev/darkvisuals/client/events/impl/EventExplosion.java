package dev.darkvisuals.client.events.impl;

import dev.darkvisuals.client.events.Event;
import lombok.Getter;
import net.minecraft.util.math.Vec3d;

/**
 * Постится клиентским миксином в ClientPlayNetworkHandler#onExplosion (HEAD),
 * то есть на каждый взрыв, о котором сервер уведомил клиента пакетом
 * ExplosionS2CPacket — в т.ч. взрыв игрового TNT. Не является "истинным"
 * событием именно TNT (сервер не различает источник в этом пакете), но это
 * единственный надёжный клиентский хук на сам факт взрыва рядом с игроком,
 * доступный без серверных модов — тот же подход использует AntiRodPullMixin
 * в этом проекте для перехвата ExplosionS2CPacket.
 */
@Getter
public class EventExplosion extends Event {
    private final Vec3d center;

    public EventExplosion(Vec3d center) {
        this.center = center;
    }
}
