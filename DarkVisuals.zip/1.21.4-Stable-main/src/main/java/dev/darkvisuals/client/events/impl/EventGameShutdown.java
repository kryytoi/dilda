package dev.darkvisuals.client.events.impl;

import dev.darkvisuals.client.events.Event;

public class EventGameShutdown extends Event {
    // Событие вызывается при выключении игры
} 