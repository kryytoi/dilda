package dev.darkvisuals.client.ui.hud;

import dev.darkvisuals.modules.impl.render.HUD;
import dev.darkvisuals.modules.settings.api.Nameable;

/**
 * Глобальный стиль HUD-элементов.
 *
 * GLOWING       — неоновое свечение и акцентная обводка (стиль TargetHUD).
 * MINIMALISTIC  — плоский тёмный дизайн без свечения (#121214, ~85% opacity).
 *
 * Реализует Nameable, чтобы работать внутри EnumSetting
 * (ClickGUI и ConfigManager используют getName() для отображения и сохранения).
 */
public enum HudStyle implements Nameable {
    GLOWING("Glowing"),
    MINIMALISTIC("Minimalistic");

    private final String displayName;

    HudStyle(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public String getName() {
        return displayName;
    }

    /** Текущий глобальный стиль (по умолчанию GLOWING, если модуль ещё не создан). */
    public static HudStyle current() {
        HUD hud = HUD.getInstance();
        if (hud != null) {
            return hud.getHudStyle();
        }
        return GLOWING;
    }

    public static boolean isGlowing() {
        return current() == GLOWING;
    }
}