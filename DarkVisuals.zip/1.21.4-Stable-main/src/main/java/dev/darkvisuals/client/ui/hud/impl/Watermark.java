package dev.darkvisuals.client.ui.hud.impl;

import dev.darkvisuals.client.events.impl.EventRender2D;
import dev.darkvisuals.client.ui.hud.HudElement;
import dev.darkvisuals.client.managers.ThemeManager;
import dev.darkvisuals.client.util.renderer.Render2D;
import dev.darkvisuals.client.util.renderer.fonts.Fonts;
import dev.darkvisuals.client.util.renderer.fonts.Font;
import dev.darkvisuals.client.util.perf.Perf;

import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.util.Identifier;
import java.awt.Color;

/**
 * Watermark: логотип (assets/darkvisuals/hud/logo.png) + название + ник + FPS + пинг.
 * Фон рисуется через единый переключатель стиля HUD (Render2D.drawHudBackground),
 * поэтому Watermark подчиняется режиму Glowing / Minimalistic.
 */
public class Watermark extends HudElement implements ThemeManager.ThemeChangeListener {

    // Логотип клиента слева в пилюле
    private static final Identifier LOGO_TEXTURE = Identifier.of("darkvisuals", "hud/logo.png");

    private final ThemeManager themeManager;
    private Color textColor;
    private Color accentColor;

    private float totalWidth, totalHeight;

    public Watermark() {
        super("Watermark");
        this.themeManager = ThemeManager.getInstance();
        applyTheme(themeManager.getCurrentTheme());
        themeManager.addThemeChangeListener(this);
    }

    private void applyTheme(ThemeManager.Theme theme) {
        this.textColor = Color.WHITE;
        this.accentColor = theme.getAccentColor();
    }

    @Override
    public void onThemeChanged(ThemeManager.Theme theme) {
        applyTheme(theme);
    }

    private String getUsername() {
        try {
            if (mc.player != null && mc.player.getGameProfile() != null) {
                String name = mc.player.getGameProfile().getName();
                if (name != null && !name.isEmpty()) return name;
            }
        } catch (Throwable ignored) {}
        return "Player";
    }

    private int getPing() {
        try {
            if (mc.player != null && mc.getNetworkHandler() != null) {
                PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (entry != null) return entry.getLatency();
            }
        } catch (Throwable ignored) {}
        return 0;
    }

    @Override
    public void onRender2D(EventRender2D e) {
        if (fullNullCheck() || closed()) return;
        Perf.tryBeginFrame();
        try (var __ = Perf.scopeCpu("Watermark.onRender2D")) {

            var matrices = e.getContext().getMatrices();
            Font font = Fonts.MEDIUM;

            String title = "DarkVisuals";
            String username = getUsername();
            String fps = mc.getCurrentFps() + " fps";
            String ping = getPing() + " ms";

            float fontSize = 7f;
            float dotGap = 8f;
            float dotSize = 2.2f;
            float paddingX = 9f;
            float iconSize = 16f;   // размер логотипа
            float iconGap = 8f;     // отступ логотип → текст

            // Динамическая ширина строк — фон всегда точно охватывает текст
            float titleW = font.getWidth(title, fontSize);
            float userW  = font.getWidth(username, fontSize);
            float fpsW   = font.getWidth(fps, fontSize);
            float pingW  = font.getWidth(ping, fontSize);

            // Полная ширина одного разделителя: отступ + точка + отступ
            float sepW = dotGap + dotSize + dotGap;

            totalHeight = 20f;
            totalWidth = paddingX + iconSize + iconGap
                    + titleW + sepW
                    + userW + sepW
                    + fpsW + sepW
                    + pingW + paddingX;

            setBounds(getX(), getY(), totalWidth, totalHeight);

            float x = getX(), y = getY();
            float r = totalHeight / 2f;
            Color liveAccent = themeManager.getCurrentTheme().getAccentColor();
            float fade = toggledAnimation.getValue();

            // ===== Фон: единый переключатель стиля HUD (Glowing / Minimalistic) =====
            Render2D.drawHudBackground(matrices, x, y, totalWidth, totalHeight, r, fade);

            // ===== Логотип =====
            float iconX = x + paddingX;
            float iconY = y + (totalHeight - iconSize) / 2f;
            Render2D.drawTexture(matrices, iconX, iconY, iconSize, iconSize, 0f, LOGO_TEXTURE, Color.WHITE);

            // ===== Текст: название • ник • FPS • пинг =====
            float textY = y + (totalHeight - font.getHeight(fontSize)) / 2f;
            float cursorX = iconX + iconSize + iconGap;

            drawGlassText(matrices, font, fontSize, title, cursorX, textY);
            cursorX += titleW;
            cursorX = drawSep(matrices, cursorX, y, totalHeight, dotGap, dotSize, liveAccent);

            drawGlassText(matrices, font, fontSize, username, cursorX, textY);
            cursorX += userW;
            cursorX = drawSep(matrices, cursorX, y, totalHeight, dotGap, dotSize, liveAccent);

            drawGlassText(matrices, font, fontSize, fps, cursorX, textY);
            cursorX += fpsW;
            cursorX = drawSep(matrices, cursorX, y, totalHeight, dotGap, dotSize, liveAccent);

            drawGlassText(matrices, font, fontSize, ping, cursorX, textY);

            super.onRender2D(e);
        }
    }

    /** Текст: тень в режиме Glowing, чистый текст в режиме Minimalistic. */
    private void drawGlassText(net.minecraft.client.util.math.MatrixStack matrices,
                               Font font, float fontSize, String text, float x, float y) {
        Render2D.drawHudText(matrices, font.getFont(fontSize), text, x, y, textColor);
    }

    /** Точка-разделитель. Продвигает курсор ровно на dotGap + dotSize + dotGap. */
    private float drawSep(net.minecraft.client.util.math.MatrixStack matrices,
                          float cursorX, float y, float h, float dotGap, float dotSize, Color accent) {
        float dotX = cursorX + dotGap;
        float dotY = y + (h - dotSize) / 2f;
        Render2D.drawRoundedRect(matrices, dotX, dotY, dotSize, dotSize, dotSize / 2f, accent);
        return dotX + dotSize + dotGap;
    }
}