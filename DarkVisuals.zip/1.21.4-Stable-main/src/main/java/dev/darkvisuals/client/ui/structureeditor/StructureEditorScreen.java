package dev.darkvisuals.client.ui.structureeditor;

import dev.darkvisuals.client.managers.ThemeManager;
import dev.darkvisuals.client.util.renderer.Render2D;
import dev.darkvisuals.client.util.renderer.fonts.Fonts;
import dev.darkvisuals.modules.impl.render.StructureVisualer;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.text.Text;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import org.joml.Matrix4f;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * GUI-редактор постройки для модуля "Structure Visualer".
 *
 * Layout:
 *  - слева вверху заголовок "Structure Visualer" + кнопка "Сохранить и перенести";
 *  - справа вверху поле поиска "Search..." с лупой;
 *  - справа панель материалов (список блоков, выбранный подсвечен фиолетовым);
 *  - центр — изометрический холст: сетка пола 16x16 + 3D-модель постройки;
 *    ЛКМ — поставить выбранный блок (на сетку или на другой блок),
 *    ПКМ — убрать блок под курсором.
 *
 * Стиль мода: тёмный фон, скруглённые углы, фиолетовые акценты темы.
 */
public class StructureEditorScreen extends Screen {

    // =====================================================================
    // Константы
    // =====================================================================

    private static final int GRID = 16;            // размер пола, блоков в сторону
    private static final float PANEL_MARGIN = 20f; // отступ основной панели от края окна
    private static final float PAD = 16f;          // внутренний отступ панели
    private static final float HEADER_H = 34f;     // высота шапки
    private static final float LIST_W = 186f;      // ширина панели материалов
    private static final float ITEM_H = 32f;       // высота строки списка
    private static final float SEARCH_W = 172f;    // ширина поля поиска
    private static final float SEARCH_H = 22f;

    private static final Color BG_PANEL = new Color(14, 14, 18, 250);
    private static final Color BG_CANVAS = new Color(20, 20, 26, 255);
    private static final Color BG_LIST = new Color(22, 22, 29, 235);
    private static final Color BG_SEARCH = new Color(30, 30, 40, 255);

    // Материал в списке: русское имя + Block (для иконки и id)
    private record MaterialDef(String name, net.minecraft.block.Block block) {
        String id() {
            return net.minecraft.registry.Registries.BLOCK.getId(block.getDefaultState().getBlock()).toString();
        }
    }

    private static final List<MaterialDef> MATERIALS = List.of(
            new MaterialDef("Дубовые Доски", Blocks.OAK_PLANKS),
            new MaterialDef("Дубовое Дерево", Blocks.OAK_LOG),
            new MaterialDef("Дубовая Кора", Blocks.OAK_WOOD),
            new MaterialDef("Дубовая Плита", Blocks.OAK_SLAB),
            new MaterialDef("Дубовая Лестница", Blocks.OAK_STAIRS),
            new MaterialDef("Дубовая Дверь", Blocks.OAK_DOOR),
            new MaterialDef("Дубовый Забор", Blocks.OAK_FENCE),
            new MaterialDef("Дубовые Листья", Blocks.OAK_LEAVES),
            new MaterialDef("Еловые Доски", Blocks.SPRUCE_PLANKS),
            new MaterialDef("Еловое Дерево", Blocks.SPRUCE_LOG),
            new MaterialDef("Берёзовые Доски", Blocks.BIRCH_PLANKS),
            new MaterialDef("Камень", Blocks.STONE),
            new MaterialDef("Булыжник", Blocks.COBBLESTONE),
            new MaterialDef("Каменная Брусчатка", Blocks.STONE_BRICKS),
            new MaterialDef("Глубинный Сланец", Blocks.DEEPSLATE),
            new MaterialDef("Сланцевая Брусчатка", Blocks.DEEPSLATE_BRICKS),
            new MaterialDef("Стекло", Blocks.GLASS),
            new MaterialDef("Кирпичи", Blocks.BRICKS),
            new MaterialDef("Песок", Blocks.SAND),
            new MaterialDef("Песчаник", Blocks.SANDSTONE),
            new MaterialDef("Блок Кварца", Blocks.QUARTZ_BLOCK),
            new MaterialDef("Кварцевая Колонна", Blocks.QUARTZ_PILLAR),
            new MaterialDef("Терракота", Blocks.TERRACOTTA),
            new MaterialDef("Мох", Blocks.MOSS_BLOCK),
            new MaterialDef("Белая Шерсть", Blocks.WHITE_WOOL),
            new MaterialDef("Кованые Прутья", Blocks.IRON_BARS),
            new MaterialDef("Факел", Blocks.TORCH)
    );

    // =====================================================================
    // Состояние
    // =====================================================================

    private final StructureVisualer module;
    private final StructureData data = new StructureData();

    private int selectedIndex = 0; // глобальный индекс в MATERIALS
    private String query = "";
    private boolean searchFocused;
    private int listScroll = 0;

    private boolean dragging; // перетаскивание установки/удаления блоков

    // Раскладка (пересчитывается каждый кадр)
    private float panelX, panelY, panelW, panelH;
    private float saveBtnX, saveBtnY, saveBtnW, saveBtnH;
    private float searchX, searchY;
    private float listX, listY, listW, listH;
    private float listAreaY, listAreaH;
    private float canvasX, canvasY, canvasW, canvasH;
    private float tw, th;          // изометрия: ширина/высота плитки
    private float originX, originY; // проекция точки (0,0,0)
    private int contentMaxY;        // высота, под которую отведён холст

    // =====================================================================
    // Конструктор
    // =====================================================================

    public StructureEditorScreen(StructureVisualer module) {
        super(Text.of("Structure Visualer"));
        this.module = module;
        module.getStructure().copyInto(data);
    }

    // =====================================================================
    // Жизненный цикл
    // =====================================================================

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    protected void init() {
        super.init();
        layout();
    }

    @Override
    public void resize(net.minecraft.client.MinecraftClient client, int w, int h) {
        super.resize(client, w, h);
        layout();
    }

    private void layout() {
        panelX = PANEL_MARGIN;
        panelY = PANEL_MARGIN;
        panelW = width - PANEL_MARGIN * 2f;
        panelH = height - PANEL_MARGIN * 2f;

        if (Fonts.SEMIBOLD == null) return;

        // Шапка: заголовок + кнопка + поиск
        float titleW = Fonts.SEMIBOLD.getWidth("Structure Visualer", 12.5f);
        saveBtnX = panelX + PAD + titleW + 14f;
        saveBtnY = panelY + 12f;
        saveBtnH = 22f;
        saveBtnW = Fonts.SEMIBOLD.getWidth("Сохранить и перенести", 8f) + 22f;
        searchX = panelX + panelW - PAD - SEARCH_W;
        searchY = panelY + 12f;

        // Контент
        float contentY = panelY + PAD + HEADER_H;
        float contentH = panelY + panelH - PAD - contentY;
        listX = panelX + panelW - PAD - LIST_W;
        listY = contentY;
        listW = LIST_W;
        listH = contentH;
        float listLabelH = 20f;
        listAreaY = listY + listLabelH;
        listAreaH = listH - listLabelH - 6f;

        float hintH = 18f;
        canvasX = panelX + PAD;
        canvasY = contentY;
        canvasW = panelW - PAD * 2f - LIST_W - 12f;
        canvasH = contentH - hintH;

        // Изометрия: подгоняем масштаб под холст
        int maxY = 6;
        for (StructureData.PlacedBlock b : data.getBlocks()) maxY = Math.max(maxY, b.y() + 1);
        contentMaxY = Math.min(StructureData.MAX_HEIGHT, maxY);
        tw = Math.min(
                (canvasW * 0.94f) / GRID,
                (2f * canvasH * 0.96f) / (GRID + contentMaxY + 1)
        );
        th = tw * 0.5f;
        originX = canvasX + canvasW / 2f;
        originY = canvasY + canvasH / 2f + (contentMaxY + 1 - GRID) * th * 0.5f;
    }

    // =====================================================================
    // Рендер
    // =====================================================================

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        if (Fonts.REGULAR == null || Fonts.SEMIBOLD == null) return;

        MatrixStack ms = context.getMatrices();
        Color accent = ThemeManager.getInstance().getCurrentTheme().getAccentColor();
        layout();

        // Основная панель
        Render2D.drawRoundedRect(ms, panelX, panelY, panelW, panelH, 12f, BG_PANEL);
        Render2D.drawBorder(ms, panelX, panelY, panelW, panelH, 12f, 1f, 1f,
                new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 90));

        renderHeader(context, ms, mouseX, mouseY, accent);
        renderList(context, ms, mouseX, mouseY, accent);
        renderCanvas(context, ms, mouseX, mouseY, accent);
        renderHint(ms);
    }

    private void renderHeader(DrawContext context, MatrixStack ms, int mouseX, int mouseY, Color accent) {
        // Заголовок
        Render2D.drawFont(ms, Fonts.SEMIBOLD.getFont(12.5f), "Structure Visualer",
                panelX + PAD, panelY + 16f, Color.WHITE);

        // Кнопка "Сохранить и перенести"
        boolean hoverBtn = isHovered(mouseX, mouseY, saveBtnX, saveBtnY, saveBtnW, saveBtnH);
        Color btnBg = hoverBtn
                ? new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 235)
                : new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 175);
        Render2D.drawRoundedRect(ms, saveBtnX, saveBtnY, saveBtnW, saveBtnH, 6f, btnBg);
        if (hoverBtn) {
            Render2D.drawBorder(ms, saveBtnX, saveBtnY, saveBtnW, saveBtnH, 6f, 1f, 1f,
                    new Color(255, 255, 255, 120));
        }
        String btnText = "Сохранить и перенести";
        float btnTW = Fonts.SEMIBOLD.getWidth(btnText, 8f);
        float btnTH = Fonts.SEMIBOLD.getHeight(8f);
        Render2D.drawFont(ms, Fonts.SEMIBOLD.getFont(8f), btnText,
                saveBtnX + (saveBtnW - btnTW) / 2f, saveBtnY + (saveBtnH - btnTH) / 2f, Color.WHITE);

        // Поле поиска с лупой
        Render2D.drawRoundedRect(ms, searchX, searchY, SEARCH_W, SEARCH_H, 6f, BG_SEARCH);
        if (searchFocused) {
            Render2D.drawBorder(ms, searchX, searchY, SEARCH_W, SEARCH_H, 6f, 1f, 1f,
                    new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 220));
        }
        drawMagnifier(ms, searchX + 13f, searchY + SEARCH_H / 2f,
                searchFocused ? new Color(200, 200, 215) : new Color(130, 130, 145));

        float textY = searchY + (SEARCH_H - Fonts.REGULAR.getHeight(8f)) / 2f;
        if (query.isEmpty()) {
            Render2D.drawFont(ms, Fonts.REGULAR.getFont(8f), "Search...",
                    searchX + 26f, textY, new Color(120, 120, 135));
        } else {
            Render2D.drawFont(ms, Fonts.REGULAR.getFont(8f), query,
                    searchX + 26f, textY, Color.WHITE);
            // курсор с миганием
            if (searchFocused && (System.currentTimeMillis() / 500L) % 2L == 0L) {
                float curX = searchX + 26f + Fonts.REGULAR.getWidth(query, 8f) + 1f;
                Render2D.drawRect(ms, curX, searchY + 5f, 1f, SEARCH_H - 10f, Color.WHITE);
            }
        }
    }

    /** Лупа: кольцо из отрезков + ручка. */
    private void drawMagnifier(MatrixStack ms, float cx, float cy, Color color) {
        float r = 4.2f;
        int segs = 14;
        for (int i = 0; i < segs; i++) {
            double a1 = Math.PI * 2 * i / segs;
            double a2 = Math.PI * 2 * (i + 1) / segs;
            Render2D.drawLine(ms,
                    (float) (cx + Math.cos(a1) * r), (float) (cy + Math.sin(a1) * r),
                    (float) (cx + Math.cos(a2) * r), (float) (cy + Math.sin(a2) * r),
                    1.4f, color);
        }
        Render2D.drawLine(ms, cx + r * 0.72f, cy + r * 0.72f, cx + r * 1.7f, cy + r * 1.7f, 1.6f, color);
    }

    // =====================================================================
    // Панель материалов (справа)
    // =====================================================================

    private record FilteredItem(int globalIndex, MaterialDef def) {}

    private List<FilteredItem> filtered() {
        List<FilteredItem> out = new ArrayList<>();
        String q = query == null ? "" : query.toLowerCase(Locale.ROOT);
        for (int i = 0; i < MATERIALS.size(); i++) {
            MaterialDef m = MATERIALS.get(i);
            if (q.isEmpty()) { out.add(new FilteredItem(i, m)); continue; }
            if (m.name().toLowerCase(Locale.ROOT).contains(q)
                    || m.id().toLowerCase(Locale.ROOT).contains(q)) {
                out.add(new FilteredItem(i, m));
            }
        }
        return out;
    }

    private void renderList(DrawContext context, MatrixStack ms, int mouseX, int mouseY, Color accent) {
        Render2D.drawRoundedRect(ms, listX, listY, listW, listH, 10f, BG_LIST);
        Render2D.drawFont(ms, Fonts.REGULAR.getFont(6.5f), "МАТЕРИАЛЫ",
                listX + 10f, listY + 7f, new Color(150, 150, 165));

        List<FilteredItem> items = filtered();
        int maxScroll = Math.max(0, items.size() * (int) ITEM_H - (int) listAreaH + 4);
        listScroll = Math.max(0, Math.min(maxScroll, listScroll));

        context.enableScissor((int) (listX + 4), (int) listAreaY, (int) (listX + listW - 4), (int) (listAreaY + listAreaH));
        for (int i = 0; i < items.size(); i++) {
            MaterialDef m = items.get(i).def();
            float iy = listAreaY + i * ITEM_H - listScroll + 2f;
            if (iy + ITEM_H < listAreaY || iy > listAreaY + listAreaH) continue;

            boolean selected = items.get(i).globalIndex() == selectedIndex;
            boolean hover = isHovered(mouseX, mouseY, listX + 4f, iy, listW - 8f, ITEM_H);

            if (selected) {
                Render2D.drawRoundedRect(ms, listX + 5f, iy, listW - 10f, ITEM_H, 6f,
                        new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 64));
                Render2D.drawBorder(ms, listX + 5f, iy, listW - 10f, ITEM_H, 6f, 1f, 1f,
                        new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 200));
            } else if (hover) {
                Render2D.drawRoundedRect(ms, listX + 5f, iy, listW - 10f, ITEM_H, 6f,
                        new Color(255, 255, 255, 10));
            }

            // иконка блока (3D-модель в 2D)
            context.drawItem(new ItemStack(m.block), (int) (listX + 10), (int) (iy + 6));

            float ty = iy + (ITEM_H - Fonts.REGULAR.getHeight(8f)) / 2f;
            Render2D.drawFont(ms, Fonts.REGULAR.getFont(8f), m.name(),
                    listX + 38f, ty, selected ? Color.WHITE : new Color(215, 215, 225));
        }
        context.disableScissor();

        // полоса прокрутки
        if (maxScroll > 0) {
            float trackH = listAreaH;
            float thumbH = Math.max(18f, trackH * (float) listAreaH / (items.size() * ITEM_H));
            float t = (float) listScroll / maxScroll;
            float thumbY = listAreaY + t * (trackH - thumbH);
            Render2D.drawRoundedRect(ms, listX + listW - 5f, thumbY, 2.5f, thumbH, 1.5f,
                    new Color(255, 255, 255, 60));
        }
    }

    // =====================================================================
    // Изометрический холст
    // =====================================================================

    private float px(float fx, float fz, float fy) {
        return originX + (fx - fz) * tw * 0.5f;
    }

    private float py(float fx, float fz, float fy) {
        return originY + (fx + fz) * th * 0.5f - fy * th;
    }

    private record Pick(BlockPos3 hover, BlockPos3 place) {}

    private record BlockPos3(int x, int y, int z) {
        BlockPos3 offset(int dx, int dy, int dz) {
            return new BlockPos3(x + dx, y + dy, z + dz);
        }
    }

    private void renderCanvas(DrawContext context, MatrixStack ms, int mouseX, int mouseY, Color accent) {
        // фон холста
        Render2D.drawRoundedRect(ms, canvasX, canvasY, canvasW, canvasH, 10f, BG_CANVAS);
        Render2D.drawBorder(ms, canvasX, canvasY, canvasW, canvasH, 10f, 1f, 1f,
                new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 50));

        // --- сетка пола ---
        Color lineCol = new Color(255, 255, 255, 22);
        for (int i = 0; i <= GRID; i++) {
            float a1x = px(i, 0, 0), a1y = py(i, 0, 0);
            float a2x = px(i, GRID, 0), a2y = py(i, GRID, 0);
            float b1x = px(0, i, 0), b1y = py(0, i, 0);
            float b2x = px(GRID, i, 0), b2y = py(GRID, i, 0);
            boolean edge = i == 0 || i == GRID;
            Render2D.drawLine(ms, a1x, a1y, a2x, a2y, 1f, edge ? new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 110) : lineCol);
            Render2D.drawLine(ms, b1x, b1y, b2x, b2y, 1f, edge ? new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 110) : lineCol);
        }

        // --- блоки (painter's algorithm: дальние → близкие) ---
        List<StructureData.PlacedBlock> sorted = new ArrayList<>(data.getBlocks());
        sorted.sort((a, b) -> {
            int by = Integer.compare(a.y() + a.x() + a.z(), b.y() + b.x() + b.z());
            return by != 0 ? by : Integer.compare(a.x() + a.z(), b.x() + b.z());
        });

        // picking
        Pick pick = pick(mouseX, mouseY);

        for (StructureData.PlacedBlock b : sorted) {
            Color base = BlockColorCache.getColor(b.blockId(), accent);
            drawIsoCube(ms, b.x(), b.y(), b.z(),
                    base,
                    shade(base, 0.72f),
                    shade(base, 0.55f),
                    235,
                    new Color(10, 10, 14, 120));

            // Иконка блока на верхней грани — видно, какой блок поставлен
            drawBlockIconOnCube(context, b.blockId(), b.x(), b.y(), b.z());
        }

        // подсветка блока под курсором (цель удаления) — красная обводка
        if (pick != null && pick.hover() != null) {
            Color red = new Color(255, 80, 80, 220);
            cubeOutline(ms, pick.hover().x(), pick.hover().y(), pick.hover().z(), red, 1.4f);
        }

        // призрак установки (голубовато-фиолетовый)
        if (pick != null && pick.place() != null && !data.contains(pick.place().x(), pick.place().y(), pick.place().z())) {
            Color base = BlockColorCache.getColor(MATERIALS.get(selectedIndex).id(), accent);
            drawIsoCube(ms, pick.place().x(), pick.place().y(), pick.place().z(),
                    base,
                    shade(base, 0.72f),
                    shade(base, 0.55f),
                    140,
                    new Color(255, 255, 255, 140));
            // Иконка на призраке тоже
            drawBlockIconOnCube(context, MATERIALS.get(selectedIndex).id(),
                    pick.place().x(), pick.place().y(), pick.place().z());
        }
    }

    /** Рисует иконку блока (item texture) по центру верхней грани изокуба. */
    private void drawBlockIconOnCube(DrawContext context, String blockId, int x, int y, int z) {
        try {
            Identifier id = Identifier.tryParse(blockId);
            if (id == null) return;
            net.minecraft.block.Block block = net.minecraft.registry.Registries.BLOCK.get(id);
            if (block == null || block == net.minecraft.block.Blocks.AIR) return;

            // Центр верхней грани куба в изометрии
            float cx = px(x + 0.5f, z + 0.5f, y + 1f);
            float cy = py(x + 0.5f, z + 0.5f, y + 1f);

            // Размер иконки зависит от масштаба изометрии
            float iconSize = Math.min(tw * 0.55f, 16f);
            float iconX = cx - iconSize / 2f;
            float iconY = cy - iconSize / 2f;

            // Рисуем иконку предмета через DrawContext
            context.drawItem(new ItemStack(block), (int) iconX, (int) iconY);
        } catch (Throwable ignored) {
            // если иконку не удалось нарисовать — куб остаётся с цветом
        }
    }

    private void renderHint(MatrixStack ms) {
        String hint = "Лкм - поставить блок  Пкм - убрать блок";
        float w = Fonts.REGULAR.getWidth(hint, 7.5f);
        Render2D.drawFont(ms, Fonts.REGULAR.getFont(7.5f), hint,
                canvasX + (canvasW - w) / 2f, canvasY + canvasH + 4f, new Color(150, 150, 165));
    }

    /** Рисуем изометрический кубик (3 видимые грани + рёбра). */
    private void drawIsoCube(MatrixStack ms, int x, int y, int z,
                             Color top, Color right, Color left, int alpha, Color outline) {
        float nx = originX + (x - z) * tw * 0.5f;
        float ny = originY + (x + z) * th * 0.5f - (y + 1) * th;
        // вершины
        float nX = nx, nY = ny;                                   // N
        float eX = nx + tw * 0.5f, eY = ny + th * 0.5f;           // E
        float mX = nx, mY = ny + th;                              // M
        float wX = nx - tw * 0.5f, wY = ny + th * 0.5f;           // W
        float sX = nx + tw * 0.5f, sY = ny + th;                  // S
        float fX = nx, fY = ny + 2f * th;                         // F
        float lbX = nx - tw * 0.5f, lbY = ny + th;                // Lb

        Matrix4f m = ms.peek().getPositionMatrix();
        fillQuad(m, top, alpha, nX, nY, eX, eY, mX, mY, wX, wY);       // верх
        fillQuad(m, right, alpha, eX, eY, sX, sY, fX, fY, mX, mY);     // право
        fillQuad(m, left, alpha, wX, wY, mX, mY, fX, fY, lbX, lbY);    // лево

        if (outline != null) {
            float o = outline.getAlpha() / 255f;
            Color c = new Color(outline.getRed(), outline.getGreen(), outline.getBlue(), (int) (255 * Math.min(1f, o * 2f)));
            Render2D.drawLine(ms, nX, nY, eX, eY, 1f, c);
            Render2D.drawLine(ms, eX, eY, sX, sY, 1f, c);
            Render2D.drawLine(ms, sX, sY, fX, fY, 1f, c);
            Render2D.drawLine(ms, fX, fY, lbX, lbY, 1f, c);
            Render2D.drawLine(ms, lbX, lbY, wX, wY, 1f, c);
            Render2D.drawLine(ms, wX, wY, nX, nY, 1f, c);
            Render2D.drawLine(ms, mX, mY, fX, fY, 1f, c);
            Render2D.drawLine(ms, wX, wY, mX, mY, 1f, c);
            Render2D.drawLine(ms, mX, mY, eX, eY, 1f, c);
        }
    }

    /** Обводка кубика (для подсветки удаления). */
    private void cubeOutline(MatrixStack ms, int x, int y, int z, Color color, float width) {
        float nx = originX + (x - z) * tw * 0.5f;
        float ny = originY + (x + z) * th * 0.5f - (y + 1) * th;
        float eX = nx + tw * 0.5f, eY = ny + th * 0.5f;
        float mX = nx, mY = ny + th;
        float wX = nx - tw * 0.5f, wY = ny + th * 0.5f;
        float sX = eX, sY = ny + th;
        float fX = nx, fY = ny + 2f * th;
        float lbX = wX, lbY = ny + th;
        Render2D.drawLine(ms, nx, ny, eX, eY, width, color);
        Render2D.drawLine(ms, eX, eY, sX, sY, width, color);
        Render2D.drawLine(ms, sX, sY, fX, fY, width, color);
        Render2D.drawLine(ms, fX, fY, lbX, lbY, width, color);
        Render2D.drawLine(ms, lbX, lbY, wX, wY, width, color);
        Render2D.drawLine(ms, wX, wY, nx, ny, width, color);
        Render2D.drawLine(ms, mX, mY, fX, fY, width, color);
        Render2D.drawLine(ms, wX, wY, mX, mY, width, color);
        Render2D.drawLine(ms, mX, mY, eX, eY, width, color);
    }

    /** Заполнение выпуклого квада (два треугольника), POSITION_COLOR. */
    private void fillQuad(Matrix4f m, Color color, int alpha,
                          float x1, float y1, float x2, float y2,
                          float x3, float y3, float x4, float y4) {
        float r = color.getRed() / 255f, g = color.getGreen() / 255f,
                b = color.getBlue() / 255f, a = alpha / 255f;
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
        buf.vertex(m, x1, y1, 0f).color(r, g, b, a);
        buf.vertex(m, x2, y2, 0f).color(r, g, b, a);
        buf.vertex(m, x3, y3, 0f).color(r, g, b, a);
        buf.vertex(m, x1, y1, 0f).color(r, g, b, a);
        buf.vertex(m, x3, y3, 0f).color(r, g, b, a);
        buf.vertex(m, x4, y4, 0f).color(r, g, b, a);
        BufferRenderer.drawWithGlobalProgram(buf.end());
        RenderSystem.enableCull();
    }

    private static Color shade(Color c, float f) {
        return new Color(
                (int) (c.getRed() * f),
                (int) (c.getGreen() * f),
                (int) (c.getBlue() * f),
                c.getAlpha());
    }

    private static boolean isHovered(double mx, double my, float x, float y, float w, float h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    // =====================================================================
    // Picking (обратная изометрическая проекция)
    // =====================================================================

    /**
     * Определяет: на какой существующий блок наведён курсор (hover)
     * и куда будет поставлен новый блок (place).
     */
    private Pick pick(int mouseX, int mouseY) {
        if (mouseX < canvasX || mouseX > canvasX + canvasW
                || mouseY < canvasY || mouseY > canvasY + canvasH) {
            return null;
        }
        float mx = mouseX, my = mouseY;

        // 1) существующие блоки — с передних (последние в порядке отрисовки)
        List<StructureData.PlacedBlock> sorted = new ArrayList<>(data.getBlocks());
        sorted.sort((a, b) -> {
            int by = Integer.compare(b.y() + b.x() + b.z(), a.y() + a.x() + a.z());
            return by != 0 ? by : Integer.compare(b.x() + b.z(), a.x() + a.z());
        });
        for (StructureData.PlacedBlock b : sorted) {
            float nx = originX + (b.x() - b.z()) * tw * 0.5f;
            float ny = originY + (b.x() + b.z()) * th * 0.5f - (b.y() + 1) * th;
            float nX = nx, nY = ny;
            float eX = nx + tw * 0.5f, eY = ny + th * 0.5f;
            float mX = nx, mY = ny + th;
            float wX = nx - tw * 0.5f, wY = ny + th * 0.5f;
            float sX = eX, sY = ny + th;
            float fX = nx, fY = ny + 2f * th;
            float lbX = wX, lbY = ny + th;

            if (inQuad(mx, my, nX, nY, eX, eY, mX, mY, wX, wY)) {
                return new Pick(new BlockPos3(b.x(), b.y(), b.z()),
                        new BlockPos3(b.x(), b.y() + 1, b.z()));
            }
            if (inQuad(mx, my, eX, eY, sX, sY, fX, fY, mX, mY)) {
                return new Pick(new BlockPos3(b.x(), b.y(), b.z()),
                        new BlockPos3(b.x() + 1, b.y(), b.z()));
            }
            if (inQuad(mx, my, wX, wY, mX, mY, fX, fY, lbX, lbY)) {
                return new Pick(new BlockPos3(b.x(), b.y(), b.z()),
                        new BlockPos3(b.x(), b.y(), b.z() + 1));
            }
        }

        // 2) пол (y = 0)
        float fx = ((mx - originX) / (tw * 0.5f) + (my - originY) / (th * 0.5f)) / 2f;
        float fz = ((my - originY) / (th * 0.5f) - (mx - originX) / (tw * 0.5f)) / 2f;
        int ix = (int) Math.floor(fx);
        int iz = (int) Math.floor(fz);
        if (ix >= 0 && ix < GRID && iz >= 0 && iz < GRID) {
            return new Pick(null, new BlockPos3(ix, 0, iz));
        }
        return null;
    }

    /** Точка внутри выпуклого квада (по знакам скрещенных произведений). */
    private static boolean inQuad(float px, float py,
                                  float x1, float y1, float x2, float y2,
                                  float x3, float y3, float x4, float y4) {
        double c1 = (x2 - x1) * (py - y1) - (y2 - y1) * (px - x1);
        double c2 = (x3 - x2) * (py - y2) - (y3 - y2) * (px - x2);
        double c3 = (x4 - x3) * (py - y3) - (y4 - y3) * (px - x3);
        double c4 = (x1 - x4) * (py - y4) - (y1 - y4) * (px - x4);
        boolean pos = c1 >= 0 && c2 >= 0 && c3 >= 0 && c4 >= 0;
        boolean neg = c1 <= 0 && c2 <= 0 && c3 <= 0 && c4 <= 0;
        return pos || neg;
    }

    // =====================================================================
    // Ввод
    // =====================================================================

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // поиск
        if (isHovered(mouseX, mouseY, searchX, searchY, SEARCH_W, SEARCH_H)) {
            searchFocused = true;
            return true;
        }
        searchFocused = false;

        // кнопка сохранения
        if (button == 0 && isHovered(mouseX, mouseY, saveBtnX, saveBtnY, saveBtnW, saveBtnH)) {
            saveAndTransfer();
            return true;
        }

        // список материалов
        List<FilteredItem> items = filtered();
        if (mouseX >= listX + 4 && mouseX <= listX + listW - 4 && mouseY >= listAreaY && mouseY <= listAreaY + listAreaH) {
            if (button == 0) {
                int idx = (int) ((mouseY - listAreaY + listScroll - 2f) / ITEM_H);
                if (idx >= 0 && idx < items.size()) {
                    selectedIndex = items.get(idx).globalIndex();
                    return true;
                }
            }
            return true;
        }

        // холст
        if (mouseX >= canvasX && mouseX <= canvasX + canvasW && mouseY >= canvasY && mouseY <= canvasY + canvasH) {
            if (button == 0) {
                placeAt((int) mouseX, (int) mouseY);
                dragging = true;
            } else if (button == 1) {
                removeAt((int) mouseX, (int) mouseY);
                dragging = true;
            }
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragging) {
            if (button == 0) placeAt((int) mouseX, (int) mouseY);
            else if (button == 1) removeAt((int) mouseX, (int) mouseY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (mouseX >= listX && mouseX <= listX + listW && mouseY >= listY && mouseY <= listY + listH) {
            listScroll += (int) (-verticalAmount * 14f);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (searchFocused) {
            if (keyCode == 259) { // backspace
                if (!query.isEmpty()) query = query.substring(0, query.length() - 1);
                return true;
            }
            if (keyCode == 291 || keyCode == 292 || keyCode == 293 || keyCode == 294 || keyCode == 295) {
                return true; // не даём стрелкам уходить на навигацию
            }
            if (keyCode == 290) { // escape
                searchFocused = false;
                return true;
            }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        // GLFW_MOD_ALT = 4: без ALT вводим в поиск
        if (searchFocused && (modifiers & 4) == 0 && !String.valueOf(chr).isBlank()) {
            if (query.length() < 32 && (chr >= 32 || chr == 9)) {
                query += chr;
                return true;
            }
            return false;
        }
        return super.charTyped(chr, modifiers);
    }

    // =====================================================================
    // Действия
    // =====================================================================

    private void placeAt(int mouseX, int mouseY) {
        Pick p = pick(mouseX, mouseY);
        if (p == null || p.place() == null) return;
        if (p.place().y() < 0 || p.place().y() >= StructureData.MAX_HEIGHT) return;
        data.set(p.place().x(), p.place().y(), p.place().z(), MATERIALS.get(selectedIndex).id());
    }

    private void removeAt(int mouseX, int mouseY) {
        Pick p = pick(mouseX, mouseY);
        if (p == null || p.hover() == null) return;
        data.remove(p.hover().x(), p.hover().y(), p.hover().z());
    }

    /** Кнопка "Сохранить и перенести": структура применяется к модулю, экран закрывается. */
    private void saveAndTransfer() {
        module.applyStructure(data);
        client.setScreen(null);
    }
}
