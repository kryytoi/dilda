package dev.darkvisuals.client.util;

/**
 * Общее (module <-> mixin) состояние тряски камеры от взрыва TNT.
 * Специально НЕ хранит случайный шум по кадрам (это давало бы дёрганое,
 * "телепортирующееся" дрожание) — вместо этого использует затухающую
 * синусоиду по yaw/pitch с разной частотой, что даёт плавный, предсказуемый
 * и дешёвый (без Random на каждый кадр) эффект "тряхнуло".
 * <p>
 * Читается из {@code dev.darkvisuals.mixin.TntCameraShakeMixin} на каждый
 * {@code Camera#update(...)} и пишется из {@code TnTEffect#onExplosion}.
 */
public final class TntCameraShakeState {

    private TntCameraShakeState() {}

    private static volatile long startMs = 0L;
    private static volatile long durationMs = 0L;
    private static volatile float magnitudeDeg = 0f;

    /**
     * Запускает импульс тряски.
     *
     * @param magnitudeDegrees максимальная амплитуда отклонения yaw/pitch в градусах
     * @param durationMillis   длительность полного затухания импульса
     */
    public static void trigger(float magnitudeDegrees, long durationMillis) {
        if (magnitudeDegrees <= 0f || durationMillis <= 0L) return;
        // Если уже трясёт сильнее — не перебиваем более слабым новым взрывом,
        // но если новый сильнее (или старый уже почти закончился) — перезапускаем.
        float currentRemaining = getRemainingMagnitude();
        if (magnitudeDegrees >= currentRemaining) {
            startMs = System.currentTimeMillis();
            durationMs = durationMillis;
            magnitudeDeg = magnitudeDegrees;
        }
    }

    private static float getRemainingMagnitude() {
        if (magnitudeDeg <= 0f) return 0f;
        long elapsed = System.currentTimeMillis() - startMs;
        if (elapsed >= durationMs) return 0f;
        float t = elapsed / (float) durationMs;
        return magnitudeDeg * (1f - t);
    }

    /**
     * @return {yawOffsetDegrees, pitchOffsetDegrees}, либо {0,0} если тряска не активна.
     */
    public static float[] getOffset() {
        if (magnitudeDeg <= 0f) return ZERO;
        long elapsed = System.currentTimeMillis() - startMs;
        if (elapsed >= durationMs) return ZERO;

        float t = elapsed / (float) durationMs;
        // Затухание амплитуды — квадратичное, даёт резкий толчок и мягкое угасание.
        float envelope = magnitudeDeg * (1f - t) * (1f - t);

        double seconds = elapsed / 1000.0;
        double yaw = Math.sin(seconds * 2 * Math.PI * 11.0) * envelope;
        double pitch = Math.cos(seconds * 2 * Math.PI * 7.5) * envelope * 0.6;

        return new float[]{(float) yaw, (float) pitch};
    }

    private static final float[] ZERO = {0f, 0f};
}
