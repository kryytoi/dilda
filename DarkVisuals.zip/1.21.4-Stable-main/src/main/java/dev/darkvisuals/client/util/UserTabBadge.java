package dev.darkvisuals.client.util;

import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Строит текстовый значок DarkVisuals (иконка + пробел) для вставки перед ником.
 * Иконка — это символ приватной зоны юникода "\uE100", отрисовываемый кастомным
 * vanilla-шрифтом assets/darkvisuals/font/user_tab.json (см. resource pack).
 */
public final class UserTabBadge {

    public static final Identifier FONT = Identifier.of("darkvisuals", "user_tab");
    private static final String ICON_CHAR = "\uE100";
    private static final Style ICON_STYLE = Style.EMPTY.withFont(FONT);

    private UserTabBadge() {}

    /** Значок + один пробел, готовый к склейке перед именем игрока. */
    public static Text prefix() {
        return Text.literal(ICON_CHAR + " ").setStyle(ICON_STYLE);
    }

    /** Возвращает {@code original}, если его нужно, с добавленным значком спереди. */
    public static Text apply(Text original) {
        if (original == null) return null;
        return Text.empty().append(prefix()).append(original);
    }
}
