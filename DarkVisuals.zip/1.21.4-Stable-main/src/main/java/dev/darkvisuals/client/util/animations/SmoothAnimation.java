package dev.darkvisuals.client.util.animations;

/**
 * Плавная, независимая от FPS анимация на основе дельты времени.
 *
 * Использует экспоненциальное сглаживание:
 *   value += (target - value) * (1 - e^(-speed * dt))
 *
 * Это математически эквивалентно формуле `animation + (target - animation) * speed`,
 * но корректно масштабируется по реальному прошедшему времени (dt),
 * поэтому скорость анимации одинакова на 30, 60 и 240 FPS.
 */
public class SmoothAnimation {

    private float value;
    private float target;
    private long lastUpdateMs;
    /** Скорость сходимости (единиц в секунду). 8-10 = мягко, 14-16 = быстро. */
    private final float speed;

    public SmoothAnimation(float initialValue, float speed) {
        this.value = initialValue;
        this.target = initialValue;
        this.speed = Math.max(0.01f, speed);
        this.lastUpdateMs = System.currentTimeMillis();
    }

    public void setTarget(float target) {
        this.target = target;
    }

    /** Мгновенно ставит значение и цель (без анимации). */
    public void snapTo(float v) {
        this.value = v;
        this.target = v;
        this.lastUpdateMs = System.currentTimeMillis();
    }

    /**
     * Продвигает анимацию по реальному времени и возвращает текущее значение.
     * Вызывать один раз за кадр перед чтением значения.
     */
    public float update() {
        long now = System.currentTimeMillis();
        float dt = (now - lastUpdateMs) / 1000f;
        lastUpdateMs = now;
        // Защита от гигантского скачка после лагов/свернутого окна
        if (dt > 0.1f) dt = 0.1f;
        if (dt > 0f) {
            float k = 1f - (float) Math.exp(-speed * dt);
            value += (target - value) * k;
            if (Math.abs(target - value) < 0.0015f) value = target;
        }
        return value;
    }

    public float getValue() {
        return value;
    }

    public float getTarget() {
        return target;
    }

    public boolean finished() {
        return value == target;
    }
}
