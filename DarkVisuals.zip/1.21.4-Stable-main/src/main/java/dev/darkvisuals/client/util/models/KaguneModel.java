package dev.darkvisuals.client.util.models;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

/**
 * "Кагуне" — как на референсе: 4 тонких длинных тёмно-багровых
 * щупальца-лезвия крестом со спины. Два верхних раскинуты широкой дугой
 * вверх-в стороны (как крылья), два нижних загибаются вниз-в стороны.
 * Каждое — длинная цепочка из множества коротких тонких сегментов,
 * поэтому изгиб получается гладким, а не "палочным". Кончики сходят
 * на остриё (пирамидка-шип). Цвет — тёмный кроваво-красный, плавно
 * темнеющий к кончику.
 */
public final class KaguneModel {

    private KaguneModel() {
    }

    /**
     * Цвета берутся из ThemeManager: основание = акцентный цвет темы,
     * кончик и шип — затемнённые версии того же цвета. Для градиентных
     * тем цвет «живой» и переливается вместе с GUI.
     */
    private static int themeColor(float brightness, int alpha) {
        java.awt.Color c = dev.darkvisuals.client.managers.ThemeManager.getInstance()
                .getCurrentTheme().getAccentColor();
        int r = Math.min(255, (int) (c.getRed() * brightness));
        int g = Math.min(255, (int) (c.getGreen() * brightness));
        int b = Math.min(255, (int) (c.getBlue() * brightness));
        return (alpha << 24) | (r << 16) | (g << 8) | b;
    }

    private static final int SEGMENTS = 12;          // много коротких сегментов = гладкая дуга
    private static final float PIXEL = 0.0625f;      // 1 "пиксель" = 1/16 блока

    /**
     * Конфиг каждого щупальца: { yaw, наклон назад (X), боковой крен (Z),
     * догибание за сегмент (Z), множитель длины, фаза анимации }.
     * Верхние два — широкий "крыльевой" размах, нижние два — вниз-в стороны.
     */
    private static final float[][] TENTACLES = {
            //  yaw    backX   rollZ   bendZ/seg  len    phase
            {  -14f,  -18f,   +38f,    +4.2f,    1.00f,  0.0f }, // верхнее левое
            {  +14f,  -18f,   -38f,    -4.2f,    1.00f,  1.6f }, // верхнее правое
            {  -10f,  -12f,  +112f,    +2.6f,    0.82f,  3.2f }, // нижнее левое
            {  +10f,  -12f,  -112f,    -2.6f,    0.82f,  4.8f }, // нижнее правое
    };

    public static void render(PlayerEntity player, float tickDelta, MatrixStack matrices, Vec3d cameraPos,
                              float animTime, float sizeSetting, boolean animated) {
        if (!player.isAlive() || player.isInvisible()) return;
        if (player.isGliding() || player.getPose() == EntityPose.SWIMMING || player.isInSwimmingPose()) return;

        float bodyYaw = MathHelper.lerpAngleDegrees(tickDelta, player.prevBodyYaw, player.bodyYaw);

        double px = MathHelper.lerp(tickDelta, player.prevX, player.getX()) - cameraPos.x;
        double py = MathHelper.lerp(tickDelta, player.prevY, player.getY()) - cameraPos.y;
        double pz = MathHelper.lerp(tickDelta, player.prevZ, player.getZ()) - cameraPos.z;

        matrices.push();
        matrices.translate(px, py, pz);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-bodyYaw));

        // Точка крепления — центр спины между лопаток, как на картинке.
        // Игрок при yaw=0 смотрит в +Z (после разворота на -bodyYaw),
        // поэтому спина — это -Z: смещаем НАЗАД, за тело.
        float backY = player.isSneaking() ? 0.80f : 1.05f;
        matrices.translate(0.0, backY, -0.30);
        if (player.isSneaking()) {
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(24.0f));
        }

        RenderSystem.enableBlend();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        // --- Проход 1: СВЕЧЕНИЕ в цвет темы ---
        // Аддитивный блендинг + увеличенная толщина + низкая альфа = мягкий ореол.
        // depthMask(false), чтобы полупрозрачный ореол не ломал сортировку.
        RenderSystem.depthMask(false);
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        BufferBuilder glow = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (float[] cfg : TENTACLES) {
            renderTentacle(matrices, glow, cfg, animTime, sizeSetting, animated, true);
        }
        BufferRenderer.drawWithGlobalProgram(glow.end());

        // --- Проход 2: ядро щупалец в цвет темы ---
        RenderSystem.depthMask(true);
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (float[] cfg : TENTACLES) {
            renderTentacle(matrices, buffer, cfg, animTime, sizeSetting, animated, false);
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());

        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        matrices.pop();
    }

    private static void renderTentacle(MatrixStack matrices, BufferBuilder buffer, float[] cfg,
                                       float animTime, float size, boolean animated, boolean glowPass) {
        float yaw = cfg[0];
        float backX = cfg[1];
        float rollZ = cfg[2];
        float bendZ = cfg[3];
        float lenMul = cfg[4];
        float phase = cfg[5];

        matrices.push();
        // Локальная ось Y = вдоль щупальца. Разворачиваем стартовое направление:
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(yaw));    // чуть назад-в сторону
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(backX)); // лёгкий уход назад от спины
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rollZ)); // крен: вверх-вбок / вниз-вбок

        // Ореол свечения заметно толще ядра и с низкой альфой
        float widthMul = glowPass ? 2.1f : 1.0f;
        float segLen = 2.6f * size * lenMul;                    // длинные лезвия
        float widthStart = 3.4f * size * widthMul;              // жирное мясистое основание
        float widthEnd = 0.9f * size * widthMul;                // сужается, но остаётся плотным

        // Цвета в цвет темы: основание ярче, кончик темнее.
        // У ореола — яркий цвет темы с низкой альфой (аддитивный блендинг сам "зажжёт" его).
        int colorRoot = glowPass ? themeColor(1.25f, 60) : themeColor(1.0f, 255);
        int colorTip  = glowPass ? themeColor(1.10f, 35) : themeColor(0.45f, 255);
        int colorSpike = glowPass ? themeColor(1.10f, 35) : themeColor(0.30f, 255);

        for (int seg = 0; seg < SEGMENTS; seg++) {
            float t = seg / (float) (SEGMENTS - 1);

            // Плавное догибание дуги в ту же сторону, что и крен, — так
            // верхние получаются серпом-крылом, нижние — косой вниз
            float bend = bendZ;
            float pitch = 0.0f;

            if (animated) {
                // Лёгкое "дыхание" дуги: амплитуда растёт к кончику,
                // основание почти неподвижно — силуэт с картинки сохраняется
                float amp = 0.6f + t * 2.4f;
                bend += MathHelper.sin(animTime * 0.9f + phase + seg * 0.45f) * amp;
                pitch = MathHelper.cos(animTime * 0.7f + phase + seg * 0.35f) * amp * 0.5f;
            }

            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(bend));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pitch));

            float w = MathHelper.lerp(t, widthStart, widthEnd) * 0.5f;
            int color = lerpColor(t, colorRoot, colorTip);

            Matrix4f matrix = matrices.peek().getPositionMatrix();
            float lenBlocks = segLen * PIXEL;
            cube(buffer, matrix, -w * PIXEL, 0.0f, -w * PIXEL, w * PIXEL, lenBlocks, w * PIXEL, color);

            matrices.translate(0.0, lenBlocks, 0.0);
        }

        // Острый шип-остриё на конце, как на референсе
        float tipW = widthEnd * 0.6f * PIXEL;
        float tipLen = 5.5f * size * lenMul * PIXEL;
        spike(buffer, matrices.peek().getPositionMatrix(), tipW, tipLen, colorSpike);

        matrices.pop();
    }

    /** Пирамидка: квадратное основание в y=0, вершина-остриё в (0, len, 0). */
    private static void spike(BufferBuilder buffer, Matrix4f m, float w, float len, int color) {
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        int a = (color >> 24) & 0xFF;

        // 4 боковые грани (вырожденные квады: две верхние вершины совпадают в острие)
        quad(buffer, m, -w, 0, -w,  w, 0, -w,  0, len, 0,  0, len, 0, r, g, b, a); // -Z
        quad(buffer, m,  w, 0,  w, -w, 0,  w,  0, len, 0,  0, len, 0, r, g, b, a); // +Z
        quad(buffer, m, -w, 0,  w, -w, 0, -w,  0, len, 0,  0, len, 0, r, g, b, a); // -X
        quad(buffer, m,  w, 0, -w,  w, 0,  w,  0, len, 0,  0, len, 0, r, g, b, a); // +X
        // дно
        quad(buffer, m, -w, 0, -w, -w, 0,  w,  w, 0,  w,  w, 0, -w, r, g, b, a);
    }

    private static int lerpColor(float t, int from, int to) {
        int a = (int) MathHelper.lerp(t, (from >> 24) & 0xFF, (to >> 24) & 0xFF);
        int r = (int) MathHelper.lerp(t, (from >> 16) & 0xFF, (to >> 16) & 0xFF);
        int g = (int) MathHelper.lerp(t, (from >> 8) & 0xFF, (to >> 8) & 0xFF);
        int b = (int) MathHelper.lerp(t, from & 0xFF, to & 0xFF);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static void cube(BufferBuilder buffer, Matrix4f m,
                             float x0, float y0, float z0,
                             float x1, float y1, float z1,
                             int color) {
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        int a = (color >> 24) & 0xFF;

        // +X
        quad(buffer, m, x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, r, g, b, a);
        // -X
        quad(buffer, m, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, r, g, b, a);
        // -Y (низ)
        quad(buffer, m, x1, y0, z1, x0, y0, z1, x0, y0, z0, x1, y0, z0, r, g, b, a);
        // +Y (верх)
        quad(buffer, m, x1, y1, z0, x0, y1, z0, x0, y1, z1, x1, y1, z1, r, g, b, a);
        // -Z
        quad(buffer, m, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, r, g, b, a);
        // +Z
        quad(buffer, m, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, r, g, b, a);
    }

    private static void quad(BufferBuilder buffer, Matrix4f m,
                             float x0, float y0, float z0,
                             float x1, float y1, float z1,
                             float x2, float y2, float z2,
                             float x3, float y3, float z3,
                             int r, int g, int b, int a) {
        buffer.vertex(m, x0, y0, z0).color(r, g, b, a);
        buffer.vertex(m, x1, y1, z1).color(r, g, b, a);
        buffer.vertex(m, x2, y2, z2).color(r, g, b, a);
        buffer.vertex(m, x3, y3, z3).color(r, g, b, a);
    }
}
