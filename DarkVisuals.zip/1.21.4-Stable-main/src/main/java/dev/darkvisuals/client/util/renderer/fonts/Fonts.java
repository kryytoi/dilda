package dev.darkvisuals.client.util.renderer.fonts;

import dev.darkvisuals.client.render.msdf.MsdfFont;
import dev.darkvisuals.darkvisuals;

/**
 * MSDF-шрифты мода.
 *
 * ВАЖНОЕ ИЗМЕНЕНИЕ (фикс краша при запуске мода из лаунчера):
 *
 * Раньше все шрифты собирались в static-блоке:
 *
 *     static {
 *         BOLD = new Font(MsdfFont.builder()...build());
 *         ...
 *     }
 *
 * Проблема: класс Fonts инициализируется лениво — в момент ПЕРВОГО обращения
 * к любому его полю. При запуске игры первым рисуется кастомный экран мода
 * (MainMenu), причём его успевает нарисовать даже SplashOverlay (class_425)
 * ещё во время перезагрузки ресурсов. В этот момент JSON шрифта может быть
 * ещё не готов, и MsdfFont.build() падал с NullPointerException
 * (FontData.atlas() == null).
 *
 * Так как падение происходило внутри static-блока, JVM превращала его в
 * ExceptionInInitializerError и НАВСЕГДА помечала класс Fonts как "битый":
 * любое последующее обращение к Fonts.* в этой сессии кидало ошибку —
 * игра крашилась (см. crash-report: java.lang.ExceptionInInitializerError
 * ... Caused by: NullPointerException в &lt;clinit&gt;).
 *
 * Теперь загрузка ленивая, потокобезопасная и ПОВТОРЯЕМАЯ:
 *  - load() ничего не кидает наружу (ловит любые ошибки);
 *  - при неудаче поля остаются null и loaded=false — на следующем кадре
 *    попытка повторится, когда ресурсы уже будут готовы;
 *  - static-блока, способного "отравить" класс, больше нет.
 *
 * Публичный API (Fonts.BOLD, Fonts.REGULAR, ...) сохранён, чтобы не трогать
 * десятки мест, которые их используют. Точки рендера, работающие на самом
 * раннем этапе (MainMenu), теперь вызывают Fonts.load() и пропускают кадр,
 * пока isLoaded() == false.
 */
public final class Fonts {

    public static Font BOLD;
    public static Font MEDIUM;
    public static Font REGULAR;
    public static Font SEMIBOLD;
    public static Font ICONS;
    public static Font GEISTMONO;

    private static volatile boolean loaded = false;
    /** Чтобы не спамить полным стектрейсом в лог каждый кадр — печатаем его один раз. */
    private static volatile boolean loggedError = false;

    private Fonts() {}

    /** Готовы ли шрифты к использованию (успешно загружены хотя бы раз). */
    public static boolean isLoaded() {
        return loaded;
    }

    /**
     * Принудительно (пере)собрать шрифты. Вызывается из слушателя перезагрузки
     * ресурсов (на render-потоке, уже ПОСЛЕ полной загрузки ресурспаков) —
     * это самый безопасный момент для сборки MSDF-атласов, поэтому здесь
     * build() гарантированно проходит, и к моменту показа меню шрифты готовы.
     */
    public static synchronized void reload() {
        loaded = false;
        loggedError = false;
        load();
    }

    /**
     * Ленивая, безопасная и повторяемая инициализация шрифтов.
     *
     * @return true — шрифты готовы; false — ресурсы ещё не готовы,
     *         стоит попробовать снова на следующем кадре.
     */
    public static synchronized boolean load() {
        if (loaded) return true;

        try {
            // Сначала собираем всё в локальные переменные: если хоть один
            // шрифт не собрался — не оставляем часть полей заполненными,
            // а часть null (иначе снова словим NPE где-нибудь ниже).
            Font bold      = new Font(MsdfFont.builder().atlas("sf_bold").data("sf_bold").build());
            Font medium    = new Font(MsdfFont.builder().atlas("sf_medium").data("sf_medium").build());
            Font regular   = new Font(MsdfFont.builder().atlas("sf_regular").data("sf_regular").build());
            Font semibold  = new Font(MsdfFont.builder().atlas("sf_semibold").data("sf_semibold").build());
            Font icons     = new Font(MsdfFont.builder().atlas("icons").data("icons").build());
            Font geistmono = new Font(MsdfFont.builder().atlas("geistmono-black").data("geistmono-black").build());

            BOLD = bold;
            MEDIUM = medium;
            REGULAR = regular;
            SEMIBOLD = semibold;
            ICONS = icons;
            GEISTMONO = geistmono;

            loaded = true;
            darkvisuals.LOGGER.info("[DarkVisuals] Fonts loaded successfully.");
            return true;
        } catch (Throwable t) {
            // НЕ выставляем loaded=true — на следующем кадре попробуем снова.
            // Никаких исключений наружу: класс Fonts не должен "ломаться".
            if (!loggedError) {
                // Полный стектрейс печатаем ОДИН раз — чтобы понять реальную
                // причину, если шрифты вообще не грузятся (см. logs/latest.log).
                loggedError = true;
                darkvisuals.LOGGER.error("[DarkVisuals] Не удалось собрать шрифты (реальная причина ниже):", t);
            } else {
                darkvisuals.LOGGER.warn("[DarkVisuals] Fonts not ready yet, will retry: {}", t.toString());
            }
            return false;
        }
    }
}
