package dev.darkvisuals.emotes;

import net.minecraft.client.render.entity.model.PlayerEntityModel;

public record Emote(String id, String translationKey, long durationMs, EmotePose pose) {

    @FunctionalInterface
    public interface EmotePose {
        /**
         * @param model   модель игрока (доступ к rightArm/leftArm/head и т.д.)
         * @param blend   0..1 — плавный вход/выход из анимации
         * @param seconds время с начала эмоции в секундах
         */
        void apply(PlayerEntityModel model, float blend, float seconds);
    }
}