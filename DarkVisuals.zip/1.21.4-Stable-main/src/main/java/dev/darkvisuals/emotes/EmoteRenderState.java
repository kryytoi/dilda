package dev.darkvisuals.emotes;

import java.util.UUID;

/** Duck-интерфейс для проброса UUID игрока в PlayerEntityRenderState. */
public interface EmoteRenderState {
    UUID darkvisuals$getEmoteOwner();
    void darkvisuals$setEmoteOwner(UUID uuid);
}