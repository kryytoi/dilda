package dev.darkvisuals.emotes.network;

import dev.darkvisuals.emotes.EmoteManager;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

/** Клиентская часть сети: приём эмоций других игроков. */
public final class EmotesClientNetwork {

    public static void register() {
        ClientPlayNetworking.registerGlobalReceiver(EmoteS2CPayload.ID, (payload, context) -> {
            if (payload.emoteId().isEmpty()) {
                EmoteManager.stop(payload.player());
            } else {
                EmoteManager.playRemote(payload.player(), payload.emoteId());
            }
        });

        // Чистим состояние при выходе с сервера
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> EmoteManager.clearAll());
    }

    private EmotesClientNetwork() {}
}