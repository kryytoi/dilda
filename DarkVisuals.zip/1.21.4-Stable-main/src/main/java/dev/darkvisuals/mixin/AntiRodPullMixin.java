package dev.darkvisuals.mixin;

import dev.darkvisuals.modules.impl.utility.RWHelper;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.c2s.play.TeleportConfirmC2SPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * RWHelper: "Не притягивать меня удочкой".
 * <p>
 * Сервер притягивает игрока чужой удочкой одним из двух способов:
 * <ul>
 *   <li>Пакет скорости {@link EntityVelocityUpdateS2CPacket} — отменяем полностью.</li>
 *   <li>"Фантомный" пакет взрыва {@link ExplosionS2CPacket} без разрушения блоков —
 *       рывок от него тоже отменяем.</li>
 * </ul>
 * Дополнительно RWHelper держит "окно опасности" ещё ~1 секунду после того,
 * как чужой поплавок был рядом: сервер часто сначала удаляет поплавок и только
 * потом шлёт пакет рывка, поэтому проверка "поплавок рядом сейчас" сама по себе
 * пропускала бы такой пакет.
 */
@Mixin(ClientPlayNetworkHandler.class)
public class AntiRodPullMixin {

    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), cancellable = true)
    private void sv$cancelRodPull(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        RWHelper rwHelper = RWHelper.getInstance();
        if (rwHelper == null || !rwHelper.isToggled()) return;

        try {
            if (rwHelper.shouldCancelVelocityPacket(packet.getEntityId())) {
                ci.cancel();
            }
        } catch (Throwable ignored) {}
    }

    @Inject(method = "onExplosion", at = @At("HEAD"), cancellable = true)
    private void sv$cancelExplosionPull(ExplosionS2CPacket packet, CallbackInfo ci) {
        RWHelper rwHelper = RWHelper.getInstance();
        if (rwHelper == null || !rwHelper.isToggled()) return;

        try {
            if (rwHelper.shouldCancelExplosionKnockback()) {
                ci.cancel();
            }
        } catch (Throwable ignored) {}
    }

    /**
     * ГЛАВНЫЙ канал притягивания на современных серверах (1.21.2+):
     * рывок игроку приходит НЕ пакетом скорости, а пакетом синхронизации
     * позиции {@link PlayerPositionLookS2CPacket} с относительными флагами
     * (позиция не меняется, меняется только скорость). Именно поэтому
     * отмена EntityVelocityUpdateS2CPacket ничего не давала на ReallyWorld.
     * <p>
     * Мы отменяем такой пакет, но ОБЯЗАТЕЛЬНО сами подтверждаем телепорт
     * ({@link TeleportConfirmC2SPacket}), иначе сервер кикнет за
     * неподтверждённый teleportId. Настоящие телепорты (со сменой позиции)
     * пропускаются — их отмена вызвала бы рассинхрон и кик.
     */
    @Inject(method = "onPlayerPositionLook", at = @At("HEAD"), cancellable = true)
    private void sv$cancelPositionVelocityPull(PlayerPositionLookS2CPacket packet, CallbackInfo ci) {
        RWHelper rwHelper = RWHelper.getInstance();
        if (rwHelper == null || !rwHelper.isToggled()) return;

        try {
            if (rwHelper.shouldCancelPositionLookVelocity(packet)) {
                // Подтверждаем телепорт вручную, чтобы сервер не кикнул нас
                ((ClientPlayNetworkHandler) (Object) this)
                        .sendPacket(new TeleportConfirmC2SPacket(packet.teleportId()));
                ci.cancel();
            }
        } catch (Throwable ignored) {}
    }
}
