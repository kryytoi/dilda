package dev.darkvisuals.mixin;

import dev.darkvisuals.darkvisuals;
import dev.darkvisuals.client.events.impl.EventExplosion;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Единственная точка входа для обнаружения взрыва на клиенте.
 * onExplosion(ExplosionS2CPacket) — единственный клиентский колбэк, который
 * вызывается ДО того как ExplosionS2CPacket.apply(...) применит толчок игроку
 * и до того, как ClientWorld спавнит ExplosionEmitterParticle — то есть у нас
 * гарантированно есть шанс отреагировать раньше или одновременно с ванильными
 * частицами. Мы намеренно НЕ отменяем и не трогаем сам пакет: только читаем
 * center() (record-компонент ExplosionS2CPacket в 1.21.4+build.8) и постим
 * своё лёгкое событие в шину мода.
 * <p>
 * Сигнатура record-класса подтверждена под yarn 1.21.4+build.8:
 * {@code ExplosionS2CPacket(Vec3d center, Optional<Vec3d> playerKnockback,
 * ParticleEffect explosionParticle, RegistryEntry<SoundEvent> explosionSound)}.
 */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class ExplosionListenerMixin {

    @Inject(method = "onExplosion", at = @At("HEAD"))
    private void darkvisuals$onExplosion(ExplosionS2CPacket packet, CallbackInfo ci) {
        try {
            darkvisuals.post(new EventExplosion(packet.center()));
        } catch (Throwable ignored) {
            // Полная защита: если формат пакета когда-либо изменится в другой сборке
            // маппингов, модуль просто не получит событие, но игру это не уронит.
        }
    }
}
