package dev.darkvisuals.mixin;

// This class has been moved to dev.darkvisuals.util.HitColorTintState.
// Keeping an empty stub prevents class-not-found during hot-reload if any stale references exist.
@Deprecated
final class HitColorTintState {}
