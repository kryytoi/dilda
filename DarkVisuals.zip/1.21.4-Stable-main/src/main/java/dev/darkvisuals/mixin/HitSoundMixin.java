package dev.darkvisuals.mixin;

import dev.darkvisuals.darkvisuals;
import dev.darkvisuals.modules.impl.utility.HitSound;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Mixin(PlayerEntity.class)
public abstract class HitSoundMixin {

	/**
	 * Кэш SoundEvent'ов: НЕ создаём новый SoundEvent на каждый удар.
	 * Повторное использование одного и того же SoundEvent означает, что после
	 * первой загрузки звук уже лежит в кэше SoundLoader и computeIfAbsent
	 * просто возвращает готовое значение, не гоняя загрузчик каждый раз.
	 */
	@Unique
	private static final Map<String, SoundEvent> darkvisuals$soundCache = new ConcurrentHashMap<>();

	@Inject(method = "attack", at = @At("HEAD"))
	private void onAttack(Entity target, CallbackInfo ci) {
		MinecraftClient mc = MinecraftClient.getInstance();

		// Хитсаунд только для нашего игрока (attack вызывается и для других PlayerEntity)
		if (mc.player == null || (Object) this != mc.player) return;

		HitSound module = darkvisuals.getInstance().getModuleManager().getModule(HitSound.class);
		if (module == null || !module.isToggled() || !(target instanceof LivingEntity)) return;

		float volume = module.getVolume().getValue();
		String soundId = module.getSelectedSound();

		SoundEvent sound = darkvisuals$soundCache.computeIfAbsent(
				soundId, id -> SoundEvent.of(Identifier.of(id)));

		try {
			// SoundLoader.loadedSounds в ванилле — не потокобезопасный HashMap.
			// Если звук ещё грузится асинхронно, computeIfAbsent может кинуть
			// ConcurrentModificationException. Ловим её, чтобы не крашить клиент:
			// в худшем случае один хитсаунд просто не проиграется.
			mc.getSoundManager().play(
					PositionedSoundInstance.master(sound, 1.0f, volume));
		} catch (java.util.ConcurrentModificationException ignored) {
			// Редкая гонка загрузчика звуков — пропускаем этот хитсаунд.
		}
	}
}
