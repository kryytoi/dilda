package dev.darkvisuals.mixin;

import dev.darkvisuals.darkvisuals;
import dev.darkvisuals.client.events.impl.EventTick;
import dev.darkvisuals.client.events.impl.EventGameShutdown;
import dev.darkvisuals.client.util.math.Counter;
import dev.darkvisuals.client.managers.HitDetectionManager;
import dev.darkvisuals.client.util.Wrapper;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin implements Wrapper {

    private static int tickCounter = 0;

    @Inject(method = "tick", at = @At("HEAD"))
    public void tick(CallbackInfo ci) {
        EventTick event = new EventTick();
        darkvisuals.post(event);
        Counter.updateFPS();

        // Периодическая очистка HitDetectionManager (каждые 20 тиков = 1 секунда)
        tickCounter++;
        if (tickCounter >= 20) {
            HitDetectionManager.getInstance().cleanup();
            tickCounter = 0;
        }
    }

    @Inject(method = "getWindowTitle", at = @At("HEAD"), cancellable = true)
    public void updateWindowTitle(CallbackInfoReturnable<String> cir) {
        cir.setReturnValue("DarkVisuals Release 0.1");
    }

    @Inject(method = "stop", at = @At("HEAD"))
    private void onStop(CallbackInfo ci) {
        // Гасим внешние фоновые интеграции до закрытия клиента, чтобы JVM не висела после выхода.
        dev.darkvisuals.util.DiscordRichPresenceUtil.shutdownDiscord();
        dev.darkvisuals.client.managers.CosmeticsSyncManager.shutdown();
        dev.darkvisuals.client.managers.UserTabManager.shutdown();

        // Публикуем событие выключения игры для автосохранения конфигурации.
        darkvisuals.post(new EventGameShutdown());
    }
}