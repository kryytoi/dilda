package dev.darkvisuals.mixin;

import dev.darkvisuals.modules.impl.utility.MyNick;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * MyNick: форсирует рендер собственного ника над головой.
 * <p>
 * Yarn 1.21.4: {@code LivingEntityRenderer.hasLabel(Lnet/minecraft/entity/LivingEntity;D)Z}
 * решает, рисовать ли табличку с ником. Для локального игрока ванилла
 * возвращает {@code false} — мы перекрываем это, когда модуль включён.
 */
@Mixin(LivingEntityRenderer.class)
public class SelfNameTagMixin {

    @Inject(
            method = "hasLabel(Lnet/minecraft/entity/LivingEntity;D)Z",
            at = @At("HEAD"),
            cancellable = true
    )
    private void sv$forceOwnNameTag(LivingEntity entity, double squaredDistanceToCamera, CallbackInfoReturnable<Boolean> cir) {
        try {
            MyNick myNick = MyNick.getInstance();
            if (myNick != null && myNick.shouldForceOwnLabel(entity)) {
                cir.setReturnValue(true);
            }
        } catch (Throwable ignored) {}
    }
}