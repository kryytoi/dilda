package dev.darkvisuals.mixin;

import dev.darkvisuals.client.util.TntCameraShakeState;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Тряска камеры от близких взрывов TNT.
 * <p>
 * Внедряемся в {@code Camera#update(...)} (тот же метод, в котором
 * {@code CameraMixin} уже переопределяет clipToSpace для плавного зума) и
 * в самом конце (TAIL, т.е. когда камера уже пересчитала штатные yaw/pitch
 * на этот кадр) добавляем небольшое смещение по yaw/pitch, посчитанное в
 * {@link TntCameraShakeState}. Мы не трогаем позицию камеры (setPos) —
 * только углы, этого достаточно для убедительной "тряски" и не ломает
 * коллизии/клиппинг камеры сквозь стены, которым занимается clipToSpace.
 */
@Mixin(Camera.class)
public abstract class TntCameraShakeMixin {

    @Shadow protected abstract void setRotation(float yaw, float pitch);

    @Inject(method = "update", at = @At("TAIL"))
    private void darkvisuals$applyTntShake(BlockView area, Entity focusedEntity, boolean thirdPerson,
                                            boolean inverseView, float tickDelta, CallbackInfo ci) {
        float[] offset = TntCameraShakeState.getOffset();
        if (offset[0] == 0f && offset[1] == 0f) return;

        Camera self = (Camera) (Object) this;
        this.setRotation(self.getYaw() + offset[0], self.getPitch() + offset[1]);
    }
}
