package dev.darkvisuals.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.darkvisuals.darkvisuals;
import dev.darkvisuals.modules.impl.render.TnTEffect;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.TntEntityRenderer;
import net.minecraft.client.render.entity.state.TntEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Пульсация масштаба + свечение блока TNT перед детонацией.
 * <p>
 * Хук — {@code TntEntityRenderer#render(TntEntityRenderState, MatrixStack,
 * VertexConsumerProvider, int)} (подтверждено под yarn 1.21.4+build.8:
 * рендерер работает через render-state, а не напрямую с TntEntity;
 * {@code TntEntityRenderState.fuse} — публичное float-поле, уже
 * интерполированное движком между тиками, обновляется в
 * {@code updateRenderState(TntEntity, TntEntityRenderState, float)}).
 * <p>
 * Мы НЕ переопределяем (@Overwrite) сам render — это тяжело поддерживать
 * между версиями маппингов (там ручная сборка BlockState-модели). Вместо
 * этого:
 *  - HEAD: подменяем масштаб через MatrixStack.scale(...) перед тем как
 *    ванильный код нарисует блок — пульсация нарастает по мере убывания fuse;
 *    push() здесь специально не закрывается сразу — тело ванильного render()
 *    выполняется МЕЖДУ нашими HEAD- и TAIL-инъекциями, поэтому push должен
 *    "охватить" его целиком, а pop() выполняется в TAIL;
 *  - TAIL: закрывает открытый в HEAD push() и ставит запрос на отрисовку
 *    "ореола" свечения в очередь модуля ({@code TnTEffect#queueFuseGlow}) —
 *    сам ореол рисуется отдельным проходом в {@code TnTEffect#onRender3D}
 *    (billboard-quad через Tessellator, как и частицы ударной волны), а не
 *    прямо здесь, чтобы не тянуть в мискин рендер-код и не резать батчинг.
 */
@Mixin(TntEntityRenderer.class)
public abstract class TntFuseRenderMixin {

    @Inject(method = "render", at = @At("HEAD"))
    private void darkvisuals$onFuseRenderHead(TntEntityRenderState state, MatrixStack matrices,
                                               VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        TnTEffect module = darkvisuals.getInstance().getModuleManager().getModule(TnTEffect.class);
        if (module == null || !module.isToggled() || !module.fusePulse.getValue()) return;

        float scale = module.getFusePulseScale(state.fuse);
        if (scale == 1f) return;

        // Масштабирование вокруг точки (0.5, 0.5, 0.5) — стандартный приём "scale вокруг pivot":
        // сдвигаемся к центру блока, масштабируем, сдвигаемся обратно. Работает независимо от
        // того, как именно устроены внутренние трансформации ванильного render(...) — они лишь
        // продолжат строиться поверх уже изменённого нами top матрицы стека.
        matrices.push();
        matrices.translate(0.5, 0.5, 0.5);
        matrices.scale(scale, scale, scale);
        matrices.translate(-0.5, -0.5, -0.5);
        // Стек нарочно НЕ восстанавливается здесь (pop идёт в TAIL) — ванильный render()
        // рисует блок именно между HEAD и TAIL этой инъекции, поэтому наш push должен
        // "охватывать" всё тело метода.
        darkvisuals$pendingPop = true;
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void darkvisuals$onFuseRenderTail(TntEntityRenderState state, MatrixStack matrices,
                                               VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        if (darkvisuals$pendingPop) {
            matrices.pop();
            darkvisuals$pendingPop = false;
        }

        TnTEffect module = darkvisuals.getInstance().getModuleManager().getModule(TnTEffect.class);
        if (module == null || !module.isToggled() || !module.fuseGlow.getValue()) return;

        RenderSystem.assertOnRenderThread();
        module.queueFuseGlow(state);
    }

    @Unique
    private boolean darkvisuals$pendingPop = false;
}
