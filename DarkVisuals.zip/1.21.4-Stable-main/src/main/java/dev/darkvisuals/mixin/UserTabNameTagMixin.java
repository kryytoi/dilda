package dev.darkvisuals.mixin;

import dev.darkvisuals.client.util.UserTabBadge;
import dev.darkvisuals.modules.impl.utility.UserTab;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Добавляет значок DarkVisuals перед ником над головой игрока, если он есть
 * в списке пользователей клиента (см. {@link UserTab}).
 * <p>
 * Используется тот же приём, что и в EntityRendererNameProtectMixin: подмена
 * аргумента Text у renderLabelIfPresent, поэтому это работает для любого
 * EntityRenderer, но значок добавляется только когда текст ника совпадает
 * с одним из известных ников (см. {@link UserTab#containsDarkVisualsUser(String)}).
 */
@Mixin(EntityRenderer.class)
public class UserTabNameTagMixin<T extends Entity> {

    @ModifyVariable(
            method = "renderLabelIfPresent",
            at = @At("HEAD"),
            argsOnly = true,
            ordinal = 0
    )
    private Text darkvisuals$addUserTabBadge(Text text) {
        UserTab userTab = UserTab.getInstance();
        if (userTab == null || !userTab.isToggled() || !userTab.getShowAboveHead().getValue() || text == null) {
            return text;
        }

        if (!userTab.containsDarkVisualsUser(text.getString())) return text;

        return UserTabBadge.apply(text);
    }
}
