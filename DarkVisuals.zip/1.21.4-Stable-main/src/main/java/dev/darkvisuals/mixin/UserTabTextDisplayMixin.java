package dev.darkvisuals.mixin;

import dev.darkvisuals.client.util.UserTabBadge;
import dev.darkvisuals.modules.impl.utility.UserTab;
import net.minecraft.client.render.entity.DisplayEntityRenderer;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.Optional;

/**
 * UserTab: добавляет значок DarkVisuals в неймтеги, которые сервер рисует
 * через Text Display entity (1.19.4+), а не через ванильную табличку.
 * <p>
 * Современные плагины (в т.ч. на ReallyWorld) вешают над игроком отдельные
 * TextDisplay-сущности с ником, донатными префиксами ("[MAGISTER]"),
 * §-форматированием, PUA-глифами ресурспака и статистикой ("20 ❤").
 * Они рендерятся в {@code DisplayEntityRenderer.TextDisplayEntityRenderer}
 * и НЕ проходят через {@code EntityRenderer.renderLabelIfPresent}, поэтому
 * {@link UserTabNameTagMixin} их не видит.
 * <p>
 * Yarn 1.21.4: текст перед разбиением на строки проходит через приватный
 * {@code getLines(Lnet/minecraft/text/Text;I)} — подменяем аргумент Text.
 * <p>
 * Поиск ника устойчив к мусору: {@link UserTab#findDarkVisualsUserName(String)}
 * сам очищает строку от §-кодов и PUA-символов. Значок вставляется прямо
 * перед ником (или, если ник разбит на несколько компонентов, в начало
 * текста), при этом ВСЕ исходные компоненты, их цвета, стили и префиксы
 * сервера сохраняются без изменений.
 */
@Mixin(DisplayEntityRenderer.TextDisplayEntityRenderer.class)
public class UserTabTextDisplayMixin {

    @ModifyVariable(
            method = "getLines",
            at = @At("HEAD"),
            argsOnly = true
    )
    private Text darkvisuals$addBadgeToTextDisplay(Text text) {
        try {
            UserTab userTab = UserTab.getInstance();
            if (userTab == null || !userTab.isToggled() || !userTab.getShowAboveHead().getValue() || text == null) {
                return text;
            }

            // Защита от повторного добавления: getLines вызывается каждый кадр
            if (userTab.hasBadge(text)) return text;

            String name = userTab.findDarkVisualsUserName(text.getString());
            if (name == null) return text;

            return darkvisuals$insertBadgeBeforeName(text, name);
        } catch (Throwable ignored) {
            return text;
        }
    }

    /**
     * Пересобирает Text, вставляя значок DarkVisuals непосредственно перед
     * ником. Обход через {@code visit(StyledVisitor)} даёт плоский список
     * (стиль, строка)-сегментов с уже РАЗРЕШЁННЫМИ стилями, поэтому цвета,
     * жирность, шрифты и PUA-глифы сервера переносятся 1-в-1.
     * <p>
     * Сегмент, содержащий ник, разрезается на "до ника" и "ник + хвост",
     * значок вставляется между ними. Если ник разбит сервером на несколько
     * компонентов (редко, но бывает), выполняется fallback: значок ставится
     * в начало первой строки через {@link UserTabBadge#apply(Text)}.
     */
    @Unique
    private static Text darkvisuals$insertBadgeBeforeName(Text text, String name) {
        MutableText rebuilt = Text.empty();
        String lowerName = name.toLowerCase();
        boolean[] inserted = {false};

        text.visit((style, str) -> {
            if (!inserted[0]) {
                int idx = str.toLowerCase().indexOf(lowerName);
                if (idx != -1) {
                    // "до ника" — со своим исходным стилем
                    if (idx > 0) {
                        rebuilt.append(Text.literal(str.substring(0, idx)).setStyle(style));
                    }
                    // значок клиента (шрифт darkvisuals:user_tab)
                    rebuilt.append(UserTabBadge.apply(Text.empty()));
                    // ник и всё после него в этом сегменте — исходный стиль
                    rebuilt.append(Text.literal(str.substring(idx)).setStyle(style));
                    inserted[0] = true;
                    return Optional.empty();
                }
            }
            rebuilt.append(Text.literal(str).setStyle(style));
            return Optional.empty();
        }, Style.EMPTY);

        // Ник разбит между компонентами — ставим значок в начало первой строки
        if (!inserted[0]) {
            return UserTabBadge.apply(text);
        }

        return rebuilt;
    }
}
