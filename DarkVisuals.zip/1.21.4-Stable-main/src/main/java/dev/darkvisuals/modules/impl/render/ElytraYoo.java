package dev.darkvisuals.modules.impl.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.darkvisuals.darkvisuals;
import dev.darkvisuals.client.events.impl.EventRender3D;
import dev.darkvisuals.modules.api.Category;
import dev.darkvisuals.modules.api.Module;
import dev.darkvisuals.modules.settings.impl.BooleanSetting;
import dev.darkvisuals.modules.settings.impl.NumberSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ElytraYoo extends Module {

    // === Настройки ===
    private final BooleanSetting trail = new BooleanSetting("Trail Lines", true);
    private final NumberSetting trailCount = new NumberSetting("Trail Count", 8, 3, 25, 1);
    private final NumberSetting trailLength = new NumberSetting("Trail Length", 2.2f, 0.8f, 5.0f, 0.1f);
    private final NumberSetting trailThickness = new NumberSetting("Trail Thickness", 0.18f, 0.05f, 0.6f, 0.01f);

    private final BooleanSetting rings = new BooleanSetting("Flight Rings", true);
    private final NumberSetting ringCount = new NumberSetting("Ring Count", 4, 1, 10, 1);
    private final NumberSetting ringDistance = new NumberSetting("Ring Distance", 28f, 12f, 70f, 1f);
    private final NumberSetting ringSize = new NumberSetting("Ring Size", 2.8f, 1.2f, 6.0f, 0.1f);
    private final NumberSetting ringThickness = new NumberSetting("Ring Thickness", 0.22f, 0.08f, 0.8f, 0.01f);

    private final List<TrailLine> trailLines = new ArrayList<>();
    private final List<FlightRing> flightRings = new ArrayList<>();
    private final Random random = new Random();

    private long lastTrailSpawn = 0;
    private long lastRingSpawn = 0;

    public ElytraYoo() {
        super("Elytra Yoo", Category.Render, "Красивый полёт (МОЖЕТ РАБОТАТЬ НЕККОРЕТНО)");
        getSettings().add(trail);
        getSettings().add(trailCount);
        getSettings().add(trailLength);
        getSettings().add(trailThickness);
        getSettings().add(rings);
        getSettings().add(ringCount);
        getSettings().add(ringDistance);
        getSettings().add(ringSize);
        getSettings().add(ringThickness);
    }

    @EventHandler
    public void onRender3D(EventRender3D.Game e) {
        if (fullNullCheck()) return;

        boolean wearingElytra = mc.player.getInventory().getArmorStack(2).getItem() == Items.ELYTRA;
        if (!wearingElytra || mc.player.isOnGround()) {
            trailLines.clear();
            flightRings.clear();
            return;
        }

        long now = System.currentTimeMillis();

        // Спавн линий (раз в 1 сек)
        if (trail.getValue() && now - lastTrailSpawn > 1000) {
            spawnTrailLines();
            lastTrailSpawn = now;
        }

        // Спавн колец (раз в 1.5 сек)
        if (rings.getValue() && now - lastRingSpawn > 1500) {
            spawnFlightRings();
            lastRingSpawn = now;
        }

        renderTrails(e.getMatrices());
        renderRings(e.getMatrices());
    }

    // === Спавн линий за элитрами ===
    private void spawnTrailLines() {
        Vec3d pos = mc.player.getPos();
        Vec3d vel = mc.player.getVelocity();

        double baseX = pos.x - vel.x * 2.3;
        double baseY = pos.y + 0.65;
        double baseZ = pos.z - vel.z * 2.3;

        int count = trailCount.getValue().intValue();
        float len = trailLength.getValue();

        for (int i = 0; i < count; i++) {
            double offset = (i - count / 2.0) * 0.32;
            trailLines.add(new TrailLine(
                    baseX + offset * 0.5,
                    baseY,
                    baseZ + offset * 0.5,
                    len,
                    System.currentTimeMillis()
            ));
        }
    }

    // === Спавн вертикальных колец ===
    private void spawnFlightRings() {
        Vec3d look = mc.player.getRotationVec(1.0f);
        Vec3d pos = mc.player.getPos();

        int count = ringCount.getValue().intValue();
        float dist = ringDistance.getValue();

        for (int i = 0; i < count; i++) {
            double spread = (random.nextDouble() - 0.5) * 14;
            Vec3d ringPos = pos.add(look.multiply(dist + random.nextInt(10)))
                    .add(look.crossProduct(new Vec3d(0, 1, 0)).multiply(spread));

            flightRings.add(new FlightRing(ringPos, System.currentTimeMillis()));
        }
    }

    // === Рендер толстых линий (повёрнутых к игроку) ===
    private void renderTrails(MatrixStack matrices) {
        long now = System.currentTimeMillis();
        trailLines.removeIf(line -> now - line.spawnTime > 1100);

        if (trailLines.isEmpty()) return;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

        Vec3d cam = mc.gameRenderer.getCamera().getPos();
        float thickness = trailThickness.getValue();

        for (TrailLine line : trailLines) {
            float age = (now - line.spawnTime) / 1100f;
            float alpha = 1f - age * 0.65f;
            if (alpha < 0.15f) continue;

            int color = 0xAA44FF;
            int r = (color >> 16) & 255;
            int g = (color >> 8) & 255;
            int b = color & 255;
            int a = (int) (alpha * 255);

            Vec3d start = new Vec3d(line.x, line.y, line.z).subtract(cam);
            Vec3d end = start.add(0, 0, line.length); // направление по Z (можно поменять)

            // Поворачиваем линию к игроку (billboard по X)
            Vec3d dir = end.subtract(start).normalize();
            Vec3d right = new Vec3d(1, 0, 0); // горизонтальная ориентация

            Vec3d p1 = start.add(right.multiply(-thickness));
            Vec3d p2 = start.add(right.multiply(thickness));
            Vec3d p3 = end.add(right.multiply(thickness));
            Vec3d p4 = end.add(right.multiply(-thickness));

            Matrix4f mat = matrices.peek().getPositionMatrix();

            buffer.vertex(mat, (float) p1.x, (float) p1.y, (float) p1.z).color(r, g, b, a);
            buffer.vertex(mat, (float) p2.x, (float) p2.y, (float) p2.z).color(r, g, b, a);
            buffer.vertex(mat, (float) p3.x, (float) p3.y, (float) p3.z).color(r, g, b, a);
            buffer.vertex(mat, (float) p4.x, (float) p4.y, (float) p4.z).color(r, g, b, a);
        }

        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.enableCull();
    }

    // === Рендер вертикальных толстых колец ===
    private void renderRings(MatrixStack matrices) {
        long now = System.currentTimeMillis();
        Vec3d playerPos = mc.player.getPos();

        flightRings.removeIf(ring -> ring.pos.distanceTo(playerPos) > 60 || (now - ring.spawnTime > 9000));

        if (flightRings.isEmpty()) return;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

        Vec3d cam = mc.gameRenderer.getCamera().getPos();
        float thickness = ringThickness.getValue();

        for (FlightRing ring : flightRings) {
            double dist = ring.pos.distanceTo(playerPos);
            float age = (now - ring.spawnTime) / 9000f;
            float alpha = Math.max(0.2f, 1f - age);

            // Пульсация
            float pulse = 1f;
            if (dist < 14) {
                pulse = 1f + (float) Math.sin((now % 700) / 180.0) * 0.3f;
            }

            float size = ringSize.getValue() * pulse;

            int color = 0x00FFCC;
            int r = (color >> 16) & 255;
            int g = (color >> 8) & 255;
            int b = color & 255;
            int a = (int) (alpha * 255);

            Vec3d center = ring.pos.subtract(cam);
            int segments = 28;

            for (int i = 0; i < segments; i++) {
                double angle1 = (i / (double) segments) * Math.PI * 2;
                double angle2 = ((i + 1) / (double) segments) * Math.PI * 2;

                // Вертикальное кольцо (в плоскости Y)
                double x1 = center.x + Math.cos(angle1) * size;
                double y1 = center.y + Math.sin(angle1) * size;
                double z1 = center.z;

                double x2 = center.x + Math.cos(angle2) * size;
                double y2 = center.y + Math.sin(angle2) * size;
                double z2 = center.z;

                // Толщина
                double nx = Math.cos((angle1 + angle2) / 2) * thickness;
                double ny = Math.sin((angle1 + angle2) / 2) * thickness;

                Matrix4f mat = matrices.peek().getPositionMatrix();

                buffer.vertex(mat, (float) (x1 - nx), (float) (y1 - ny), (float) z1).color(r, g, b, a);
                buffer.vertex(mat, (float) (x2 - nx), (float) (y2 - ny), (float) z2).color(r, g, b, a);
                buffer.vertex(mat, (float) (x2 + nx), (float) (y2 + ny), (float) z2).color(r, g, b, a);
                buffer.vertex(mat, (float) (x1 + nx), (float) (y1 + ny), (float) z1).color(r, g, b, a);
            }
        }

        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.enableCull();
    }

    private static class TrailLine {
        double x, y, z, length;
        long spawnTime;

        TrailLine(double x, double y, double z, double length, long spawnTime) {
            this.x = x; this.y = y; this.z = z;
            this.length = length;
            this.spawnTime = spawnTime;
        }
    }

    private static class FlightRing {
        Vec3d pos;
        long spawnTime;

        FlightRing(Vec3d pos, long spawnTime) {
            this.pos = pos;
            this.spawnTime = spawnTime;
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        darkvisuals.getInstance().getEventHandler().subscribe(this);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        trailLines.clear();
        flightRings.clear();
        darkvisuals.getInstance().getEventHandler().unsubscribe(this);
    }
}