package dev.darkvisuals.modules.impl.render;

import dev.darkvisuals.client.ui.hud.HudStyle;
import dev.darkvisuals.modules.api.Category;
import dev.darkvisuals.modules.api.Module;
import dev.darkvisuals.modules.settings.impl.BooleanSetting;
import dev.darkvisuals.modules.settings.impl.EnumSetting;

/**
 * Модуль HUD в разделе Render.
 * При включении включается весь HUD, а в настройках можно
 * отключить отдельные элементы (TargetHUD, MusicHUD и т.д.).
 *
 * Имена настроек должны совпадать с именами HudElement'ов,
 * так как HudElement ищет свою настройку по getName().
 *
 * Настройка "Style" — глобальный стиль всех HUD-элементов:
 * Glowing (неоновое свечение) или Minimalistic (плоский тёмный дизайн).
 */
public class HUD extends Module {

    private static HUD instance;

    // ===== Глобальный стиль HUD (Glowing / Minimalistic) =====
    private final EnumSetting<HudStyle> style = new EnumSetting<>("Style", HudStyle.GLOWING);

    private final BooleanSetting watermark = new BooleanSetting("Watermark", true);
    private final BooleanSetting targetHud = new BooleanSetting("TargetHud", true);
    private final BooleanSetting potions = new BooleanSetting("Potions", true);
    private final BooleanSetting armorHud = new BooleanSetting("ArmorHUD", true);
    private final BooleanSetting hotbar = new BooleanSetting("Hotbar", true);
    private final BooleanSetting music = new BooleanSetting("Music", true);
    private final BooleanSetting betterNear = new BooleanSetting("BetterNearHUD", true);
    private final BooleanSetting keyboard = new BooleanSetting("KeyboardHUD", true);
    private final BooleanSetting inventory = new BooleanSetting("Inventory", true);

    public HUD() {
        super("HUD", Category.Render, "Отображение интерфейса клиента");
        instance = this;
        // HUD включен по умолчанию
        setToggled(true);
    }

    public static HUD getInstance() {
        return instance;
    }

    /** Текущий глобальный стиль HUD, выбранный в настройках. */
    public HudStyle getHudStyle() {
        return style.getValue();
    }

    /**
     * Видим ли HUD-элемент с указанным именем.
     * false — если модуль HUD выключен или элемент отключен в настройках.
     */
    public boolean isElementVisible(String name) {
        if (!isToggled()) return false;

        BooleanSetting setting = getElementSetting(name);
        // Если для элемента нет настройки (например, динамический PerfHUD) — показываем
        return setting == null || setting.getValue();
    }

    /**
     * Есть ли у модуля настройка для элемента с этим именем.
     */
    public boolean hasElementSetting(String name) {
        return getElementSetting(name) != null;
    }

    private BooleanSetting getElementSetting(String name) {
        for (var setting : getSettings()) {
            if (setting instanceof BooleanSetting bool && bool.getName().equalsIgnoreCase(name)) {
                return bool;
            }
        }
        return null;
    }
}
