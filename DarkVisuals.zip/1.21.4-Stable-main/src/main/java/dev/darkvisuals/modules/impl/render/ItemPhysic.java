package dev.darkvisuals.modules.impl.render;


import dev.darkvisuals.darkvisuals;
import dev.darkvisuals.modules.api.Category;
import dev.darkvisuals.modules.api.Module;
import net.minecraft.client.resource.language.I18n;

/**
 * Item Physics — предметы на земле лежат горизонтально и не подпрыгивают
 * (реалистичная "физика" выпавших предметов), по образцу известного модуля.
 */
public class ItemPhysic extends Module {

    private static ItemPhysic instance;

    public ItemPhysic() {
        super("ItemPhysic", Category.Render, I18n.translate("module.itemphysic.description"));
        instance = this;
    }

    /** Статический доступ к модулю из миксина (как в эталонном коде). */
    public static ItemPhysic get() {
        if (instance == null) {
            instance = darkvisuals.getInstance().getModuleManager().getModule(ItemPhysic.class);
        }
        return instance;
    }
}
