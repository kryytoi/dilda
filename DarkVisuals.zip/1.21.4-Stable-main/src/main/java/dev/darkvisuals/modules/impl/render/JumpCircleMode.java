package dev.darkvisuals.modules.impl.render;

import dev.darkvisuals.modules.settings.api.Nameable;

/**
 * Визуальные режимы JumpCircle.
 *
 * JAGGED_RING — зубчатое кольцо с угловатыми вырезами (circle1).
 * THICK_RING  — толстое неровное кольцо с разрывами (circle3).
 * OCTAGON     — залитый восьмиугольник с внутренним вырезом (circle4).
 * LATTICE     — круглая решётка из перекрещивающихся полос (circle5).
 * NOVA        — звёздный взрыв: кольцо с радиальными шипами + внешняя обводка (оригинальный).
 *
 * Первые два режима (DEFAULT, CIRCLE) — старые текстуры, сохранены для обратной совместимости.
 */
public enum JumpCircleMode implements Nameable {
    JAGGED_RING("Jagged Ring"),
    THICK_RING("Thick Ring"),
    OCTAGON("Octagon"),
    LATTICE("Lattice"),
    NOVA("Nova");

    private final String displayName;

    JumpCircleMode(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public String getName() {
        return displayName;
    }
}
