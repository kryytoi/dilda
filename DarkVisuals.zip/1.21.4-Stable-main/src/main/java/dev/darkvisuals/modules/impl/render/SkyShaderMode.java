package dev.darkvisuals.modules.impl.render;

import dev.darkvisuals.modules.settings.api.Nameable;

/**
 * Режимы шейдерного неба для SkyShader.
 * SKY     — атмосферный градиент с авророй и звёздами;
 * WATER   — плавная 3D-волна;
 * CAUSTIC — каустика (движущиеся световые узоры).
 */
public enum SkyShaderMode implements Nameable {
    SKY("Sky"),
    WATER("Water"),
    CAUSTIC("Caustic");

    private final String displayName;

    SkyShaderMode(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public String getName() {
        return displayName;
    }
}
