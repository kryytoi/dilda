package dev.darkvisuals.modules.impl.render;

import dev.darkvisuals.client.events.impl.EventRender3D;
import dev.darkvisuals.client.managers.ThemeManager;
import dev.darkvisuals.client.ui.structureeditor.BlockColorCache;
import dev.darkvisuals.client.ui.structureeditor.StructureData;
import dev.darkvisuals.client.ui.structureeditor.StructureEditorScreen;
import dev.darkvisuals.client.util.notify.Notify;
import dev.darkvisuals.client.util.notify.NotifyIcons;
import dev.darkvisuals.client.util.renderer.Render3D;
import dev.darkvisuals.darkvisuals;
import dev.darkvisuals.modules.api.Category;
import dev.darkvisuals.modules.api.Module;
import dev.darkvisuals.modules.settings.impl.BooleanSetting;
import dev.darkvisuals.modules.settings.impl.ButtonSetting;
import dev.darkvisuals.modules.settings.impl.NumberSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.awt.*;
import java.io.File;

/**
 * Structure Visualer — конструктор дома.
 *
 *  - кнопка "Сделать дом" открывает GUI-редактор (StructureEditorScreen):
 *    сетка пола, изометрическая 3D-модель, выбор материала, поиск;
 *  - "Сохранить и перенести" сохраняет структуру (в память + JSON в
 *    darkvisuals/structure_visualer.json) и включает в мире
 *    полупрозрачную голограмму постройки;
 *  - основание голограммы всегда привязано к блоку, на который смотрит
 *    прицел игрока (crosshair raycast) — видно, куда ставить блоки вручную.
 */
public class StructureVisualer extends Module {

    // ==== настройки (видимые в ClickGUI) ====
    private final ButtonSetting buildButton = new ButtonSetting("Сделать дом", this::openEditor);
    private final BooleanSetting hologram = new BooleanSetting("Hologram", true);
    private final BooleanSetting outline = new BooleanSetting("Block Outline", true);
    private final NumberSetting opacity = new NumberSetting("Hologram Opacity", 0.35f, 0.1f, 0.9f, 0.05f);

    // ==== состояние ====
    private final StructureData structure = new StructureData();
    private final File configFile;

    /** Блок, на который сейчас смотрит прицел (для маркера привязки). */
    private BlockPos targeted;
    /** Позиция нижнего основания голограммы (куда кладётся слой y=0). */
    private BlockPos anchor;

    public StructureVisualer() {
        super("Structure Visualer", Category.Render, I18n.translate("module.structurevisualer.description"));
        getSettings().add(buildButton);
        getSettings().add(hologram);
        getSettings().add(outline);
        getSettings().add(opacity);

        configFile = new File(darkvisuals.getInstance().getGlobalsDir(), "structure_visualer.json");
        // структура переживает перезапуск игры
        structure.loadFromFile(configFile);
    }

    public StructureData getStructure() {
        return structure;
    }

    // =====================================================================
    // Редактор
    // =====================================================================

    /** Кнопка "Сделать дом" в настройках модуля. */
    public void openEditor() {
        mc.setScreen(new StructureEditorScreen(this));
    }

    /** Вызывается экраном по "Сохранить и перенести". */
    public void applyStructure(StructureData data) {
        if (data.isEmpty()) {
            darkvisuals.getInstance().getNotifyManager().add(new Notify(NotifyIcons.failIcon,
                    "Структура пуста — поставьте хотя бы один блок.", 2500));
            return;
        }
        structure.copyFrom(data);
        structure.saveToFile(configFile);
        if (!isToggled()) setToggled(true);

        darkvisuals.getInstance().getNotifyManager().add(new Notify(NotifyIcons.successIcon,
                "Структура сохранена! Наведи прицел на блок — дом отобразится как голограмма.", 3000));
    }

    @Override
    public void onDisable() {
        targeted = null;
        anchor = null;
        super.onDisable();
    }

    // =====================================================================
    // Привязка к прицелу
    // =====================================================================

    private void updateAnchor() {
        if (fullNullCheck()) return;

        HitResult hit = mc.crosshairTarget;
        if (hit != null && hit.getType() == HitResult.Type.BLOCK) {
            BlockHitResult bhr = (BlockHitResult) hit;
            targeted = bhr.getBlockPos();
            // основание кладём туда, куда бы мы поставили блок рукой
            anchor = targeted.offset(bhr.getSide());
        } else {
            targeted = null;
            // прицел в небо/пустоту: ставим основание перед ногами игрока
            float yaw = (float) Math.toRadians(mc.player.getYaw());
            double dx = -Math.sin(yaw);
            double dz = Math.cos(yaw);
            anchor = BlockPos.ofFloored(
                    mc.player.getX() + dx * 2.0,
                    mc.player.getY() - 0.3,
                    mc.player.getZ() + dz * 2.0
            );
        }
    }

    // =====================================================================
    // Рендер голограммы
    // =====================================================================

    @EventHandler
    public void onRender3D(EventRender3D.Game e) {
        if (!isToggled() || !hologram.getValue() || fullNullCheck()) return;
        if (structure.isEmpty()) return;

        updateAnchor();
        if (anchor == null) return;

        MatrixStack ms = e.getMatrices();
        Color accent = ThemeManager.getInstance().getCurrentTheme().getAccentColor();
        float alpha = Math.max(0.05f, Math.min(1f, opacity.getValue()));

        // маркер привязки: обводка блока под прицелом
        if (targeted != null) {
            Render3D.renderBoxOutline(ms, new Box(targeted),
                    new Color(255, 255, 255, (int) (160 * alpha + 60)));
        }

        // полупрозрачные блоки: цвет берём из текстуры (видно, какой блок где)
        // Каждый блок — полноценный 1x1x1 куб, чуть меньше единицы чтобы не было z-fighting
        for (StructureData.PlacedBlock pb : structure.getBlocks()) {
            BlockPos wp = anchor.add(pb.x(), pb.y(), pb.z());
            Box box = new Box(wp).contract(0.005);
            Color base = BlockColorCache.getColor(pb.blockId(), accent);

            int fillA = (int) (255f * alpha * 0.55f);
            if (fillA > 2) {
                Render3D.renderBox(ms, box, new Color(base.getRed(), base.getGreen(), base.getBlue(), fillA));
            }
            if (outline.getValue()) {
                int lineA = (int) (255f * Math.min(1f, alpha * 0.9f + 0.15f));
                Color line = blend(base, accent, 0.4f);
                Render3D.renderBoxOutline(ms, box, new Color(line.getRed(), line.getGreen(), line.getBlue(), lineA));
            }
        }
    }

    private static Color blend(Color a, Color b, float t) {
        return new Color(
                (int) (a.getRed() * (1f - t) + b.getRed() * t),
                (int) (a.getGreen() * (1f - t) + b.getGreen() * t),
                (int) (a.getBlue() * (1f - t) + b.getBlue() * t),
                255);
    }
}
