package dev.darkvisuals.modules.impl.utility;

import dev.darkvisuals.modules.api.Category;
import dev.darkvisuals.modules.api.Module;
import dev.darkvisuals.modules.settings.impl.BooleanSetting;
import lombok.Getter;
import net.minecraft.entity.LivingEntity;

/**
 * MyNick — показывает ваш собственный ник над головой,
 * как его видят другие игроки.
 * <p>
 * Ванилла скрывает собственную табличку с ником: в
 * {@code LivingEntityRenderer.hasLabel(LivingEntity, double)} локальный
 * игрок исключается из рендера. Модуль форсирует рендер через
 * {@code SelfNameTagMixin}.
 */
public class MyNick extends Module {

    @Getter
    private static MyNick instance;

    /** Показывать ник только от третьего лица (F5). */
    @Getter
    private final BooleanSetting onlyThirdPerson = new BooleanSetting("Только от третьего лица", true);

    public MyNick() {
        super("MyNick", Category.Utility, "Показывает ваш ник над головой — как его видят другие игроки");
        instance = this;
        getSettings().add(onlyThirdPerson);
    }

    /**
     * Нужно ли форсировать рендер таблички для этой сущности.
     * Вызывается из {@code SelfNameTagMixin}.
     */
    public boolean shouldForceOwnLabel(LivingEntity entity) {
        if (!isToggled()) return false;
        if (mc.player == null || entity != mc.player) return false;
        if (onlyThirdPerson.getValue() && mc.options.getPerspective().isFirstPerson()) return false;
        return true;
    }
}