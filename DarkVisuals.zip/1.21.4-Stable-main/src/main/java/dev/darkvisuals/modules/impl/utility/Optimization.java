package dev.darkvisuals.modules.impl.utility;

import dev.darkvisuals.client.events.impl.EventTick;
import dev.darkvisuals.modules.api.Category;
import dev.darkvisuals.modules.api.Module;
import dev.darkvisuals.modules.settings.impl.BooleanSetting;
import dev.darkvisuals.modules.settings.impl.NumberSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.particle.ParticlesMode;
import org.jetbrains.annotations.NotNull;

import java.lang.reflect.Field;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.atomic.AtomicInteger;

public class Optimization extends Module {

    // --- Сохранённые значения, чтобы вернуть всё как было ---
    private ParticlesMode oldParticles = ParticlesMode.ALL;
    private double oldEntityDistance = 1.0;
    private int oldBiomeBlendRadius = 2;
    private boolean oldEntityShadows = true;
    private GraphicsMode oldGraphics = GraphicsMode.FANCY;
    private CloudRenderMode oldClouds = CloudRenderMode.FANCY;
    private boolean oldAo = true;
    private boolean oldBobView = true;
    private int oldMipmap = 4;
    private int oldMaxFps = 120;
    private boolean oldVsync = true;

    private long lastCleanup = 0L;

    // ---------------------------------------------------------------
    // Новые настройки
    // ---------------------------------------------------------------

    // Динамический ФПС: в фокусе - обычный (без лимита) ФПС, вне фокуса - заданный
    public @NotNull BooleanSetting dynamicFps = new BooleanSetting("Dynamic FPS", false);
    public @NotNull NumberSetting backgroundFps = new NumberSetting("Background FPS", 15f, 1f, 60f, 1f, dynamicFps::getValue);

    // Скрытие сущностей вне поля зрения (все, кроме игроков)
    public @NotNull BooleanSetting hideEntities = new BooleanSetting("Hide Entities", false);
    // Скрытие игроков вне поля зрения
    public @NotNull BooleanSetting hidePlayers = new BooleanSetting("Hide Players", false);
    // Скрытие блок-энтити (сундуки, кровати, вывески и т.д.) вне поля зрения
    public @NotNull BooleanSetting hideBlockEntities = new BooleanSetting("Hide Block Entities", false);

    // Лимит частиц (и выброшенных предметов) на экране
    public @NotNull BooleanSetting limitParticles = new BooleanSetting("Particle Limit", false);
    public @NotNull NumberSetting particleLimit = new NumberSetting("Max Particles", 200f, 0f, 2000f, 10f, limitParticles::getValue);

    // Реже обновлять свет (lightmap)
    public @NotNull BooleanSetting slowerLight = new BooleanSetting("Slower Light Updates", false);

    // Счётчик отрисованных за текущий кадр предметов (для лимита частиц/предметов)
    public static final AtomicInteger renderedItemsThisFrame = new AtomicInteger(0);
    // Счётчик кадров для троттлинга обновления света
    public static int lightFrameCounter = 0;

    // ---------------------------------------------------------------
    // ДОПОЛНИТЕЛЬНЫЕ ОПТИМИЗАЦИИ
    // ---------------------------------------------------------------

    // FPS-протектор: если FPS упал ниже порога — временно снижаем дальность
    public @NotNull BooleanSetting fpsProtector = new BooleanSetting("FPS Protector", false);
    public @NotNull NumberSetting fpsProtectThreshold = new NumberSetting("FPS Target", 60f, 20f, 240f, 5f, fpsProtector::getValue);

    // Adaptive render distance: снижать дальность прорисовки при низком FPS
    public @NotNull BooleanSetting adaptiveRenderDistance = new BooleanSetting("Adaptive Render Distance", false);
    public @NotNull NumberSetting maxRenderDistance = new NumberSetting("Max Render Distance", 8f, 4f, 32f, 1f, adaptiveRenderDistance::getValue);

    // Кэш для adaptive
    private double baseEntityDistance = 1.0;
    private boolean adaptiveActive = false;

    private boolean lastFocused = true;
    private Field particlesMapField; // Map<ParticleTextureSheet, Queue<Particle>> внутри ParticleManager

    public Optimization() {
        super("Optimization", Category.Utility, "Моментально повышает ФПС, убирая лишнюю нагрузку");

        getSettings().add(dynamicFps);
        getSettings().add(backgroundFps);
        getSettings().add(hideEntities);
        getSettings().add(hidePlayers);
        getSettings().add(hideBlockEntities);
        getSettings().add(limitParticles);
        getSettings().add(particleLimit);
        getSettings().add(slowerLight);
        getSettings().add(fpsProtector);
        getSettings().add(fpsProtectThreshold);
        getSettings().add(adaptiveRenderDistance);
        getSettings().add(maxRenderDistance);
    }

    @Override
    public void onEnable() {
        // ВАЖНО: сначала базовая логика (toggled = true + подписка на события).
        super.onEnable();

        if (mc.options == null) return;

        try {
            // 1. Сохраняем текущие настройки
            oldParticles       = mc.options.getParticles().getValue();
            oldEntityDistance  = mc.options.getEntityDistanceScaling().getValue();
            baseEntityDistance = mc.options.getEntityDistanceScaling().getValue();
            oldBiomeBlendRadius= mc.options.getBiomeBlendRadius().getValue();
            oldEntityShadows   = mc.options.getEntityShadows().getValue();
            oldGraphics        = mc.options.getGraphicsMode().getValue();
            oldClouds          = mc.options.getCloudRenderMode().getValue();
            oldAo              = mc.options.getAo().getValue();
            oldBobView         = mc.options.getBobView().getValue();
            oldMipmap          = mc.options.getMipmapLevels().getValue();
            oldMaxFps          = mc.options.getMaxFps().getValue();
            oldVsync           = mc.options.getEnableVsync().getValue();

            // 2. Выкручиваем всё на максимальный ФПС
            mc.options.getParticles().setValue(ParticlesMode.MINIMAL);
            mc.options.getEntityDistanceScaling().setValue(0.5);
            mc.options.getBiomeBlendRadius().setValue(0);
            mc.options.getEntityShadows().setValue(false);
            mc.options.getGraphicsMode().setValue(GraphicsMode.FAST);
            mc.options.getCloudRenderMode().setValue(CloudRenderMode.OFF);
            mc.options.getAo().setValue(false);          // отключаем ambient occlusion
            mc.options.getBobView().setValue(false);     // отключаем покачивание камеры
            mc.options.getMipmapLevels().setValue(0);    // убираем mipmaps
            mc.options.getMaxFps().setValue(260);        // 260 = без лимита
            mc.options.getEnableVsync().setValue(false); // выключаем VSync

            // Сбрасываем состояние динамического ФПС
            lastFocused = mc.isWindowFocused();

            // 3. Чистим кэш рендера и частицы прямо сейчас
            clearRenderCaches();

            // 4. Немедленная очистка памяти
            forceMemoryCleanup(true);
        } catch (Exception e) {
            System.out.println("[Optimization] Ошибка при включении: " + e.getMessage());
        }
    }

    @Override
    public void onDisable() {
        // ВАЖНО: базовая логика (toggled = false + отписка от событий).
        super.onDisable();

        if (mc.options == null) return;

        try {
            mc.options.getParticles().setValue(oldParticles);
            mc.options.getEntityDistanceScaling().setValue(oldEntityDistance);
            mc.options.getBiomeBlendRadius().setValue(oldBiomeBlendRadius);
            mc.options.getEntityShadows().setValue(oldEntityShadows);
            mc.options.getGraphicsMode().setValue(oldGraphics);
            mc.options.getCloudRenderMode().setValue(oldClouds);
            mc.options.getAo().setValue(oldAo);
            mc.options.getBobView().setValue(oldBobView);
            mc.options.getMipmapLevels().setValue(oldMipmap);
            mc.options.getMaxFps().setValue(oldMaxFps);
            mc.options.getEnableVsync().setValue(oldVsync);
        } catch (Exception e) {
            System.out.println("[Optimization] Ошибка при выключении: " + e.getMessage());
        }
    }

    // Периодическая разгрузка основного потока: чистим память по таймеру,
    // а не каждый тик, чтобы самим не создавать лаги.
    @EventHandler
    public void onTick(EventTick event) {
        handleDynamicFps();
        handleParticleLimit();
        handleFpsProtector();
        handleAdaptiveRenderDistance();

        long now = System.currentTimeMillis();
        if (now - lastCleanup < 15_000L) return; // раз в 15 секунд
        lastCleanup = now;
        forceMemoryCleanup(false);
    }

    // --- FPS-протектор: при низком FPS временно снижаем дальность сущностей ---
    private void handleFpsProtector() {
        if (mc.options == null) return;
        if (!fpsProtector.getValue()) {
            // сбрасываем, если стало плохо
            if (mc.options.getEntityDistanceScaling().getValue() != baseEntityDistance && !adaptiveRenderDistance.getValue()) {
                mc.options.getEntityDistanceScaling().setValue(baseEntityDistance);
            }
            return;
        }

        try {
            int fps = dev.darkvisuals.client.util.math.Counter.getCurrentFPS();
            float target = fpsProtectThreshold.getValue();

            if (fps < target) {
                // FPS низкий — снижаем дальность сущностей и частицы
                mc.options.getEntityDistanceScaling().setValue(0.3);
            } else {
                mc.options.getEntityDistanceScaling().setValue(baseEntityDistance);
            }
        } catch (Throwable ignored) {}
    }

    // --- Adaptive render distance: снижать дальность прорисовки при низком FPS ---
    private void handleAdaptiveRenderDistance() {
        if (mc.options == null) return;
        if (!adaptiveRenderDistance.getValue()) return;

        try {
            int fps = dev.darkvisuals.client.util.math.Counter.getCurrentFPS();
            float target = fpsProtectThreshold.getValue();
            int max = Math.round(maxRenderDistance.getValue());

            if (fps < target * 0.7) {
                // Очень низкий FPS — сильно снижаем дальность
                mc.options.getViewDistance().setValue(Math.max(2, max / 2));
                mc.options.getEntityDistanceScaling().setValue(0.25);
            } else if (fps < target) {
                // Низкий FPS — умеренно снижаем
                mc.options.getViewDistance().setValue(Math.max(2, (int)(max * 0.7)));
                mc.options.getEntityDistanceScaling().setValue(0.4);
            } else {
                mc.options.getViewDistance().setValue(max);
                mc.options.getEntityDistanceScaling().setValue(baseEntityDistance);
            }
        } catch (Throwable ignored) {}
    }

    // --- Геттер для доступа извне (при необходимости) ---
    public boolean isFpsProtectorActive() { return isToggled() && fpsProtector.getValue(); }

    // --- Динамический ФПС ---
    private void handleDynamicFps() {
        if (mc.options == null) return;
        if (!dynamicFps.getValue()) return;

        boolean focused = mc.isWindowFocused();
        if (focused == lastFocused) return; // меняем лимит только при смене состояния фокуса
        lastFocused = focused;

        try {
            if (focused) {
                mc.options.getMaxFps().setValue(260); // без лимита, пока окно активно
            } else {
                int bg = Math.max(1, Math.round(backgroundFps.getValue()));
                mc.options.getMaxFps().setValue(bg);
            }
        } catch (Throwable ignored) {}
    }

    // --- Лимит частиц (+ выброшенных предметов) ---
    private void handleParticleLimit() {
        renderedItemsThisFrame.set(0); // сбрасываем счётчик предметов на новый тик/кадр

        if (!limitParticles.getValue()) return;
        int limit = Math.round(particleLimit.getValue());

        if (mc.particleManager == null) return;

        try {
            if (particlesMapField == null) {
                for (Field f : mc.particleManager.getClass().getDeclaredFields()) {
                    if (Map.class.isAssignableFrom(f.getType())) {
                        f.setAccessible(true);
                        particlesMapField = f;
                        break;
                    }
                }
            }
            if (particlesMapField == null) return;

            Object mapObj = particlesMapField.get(mc.particleManager);
            if (!(mapObj instanceof Map<?, ?> map)) return;

            int total = 0;
            for (Object value : map.values()) {
                if (value instanceof Collection<?> collection) total += collection.size();
            }

            int toRemove = total - limit;
            if (toRemove <= 0) return;

            for (Object value : map.values()) {
                if (toRemove <= 0) break;

                if (value instanceof Queue<?> queue) {
                    while (toRemove > 0 && !queue.isEmpty()) {
                        queue.poll();
                        toRemove--;
                    }
                } else if (value instanceof Collection<?> collection) {
                    Iterator<?> it = collection.iterator();
                    while (toRemove > 0 && it.hasNext()) {
                        it.next();
                        it.remove();
                        toRemove--;
                    }
                }
            }
        } catch (Throwable ignored) {}
    }

    /**
     * Проверяет, разрешено ли отрисовать ещё один выброшенный предмет в этом кадре
     * согласно лимиту частиц. Используется мискином рендера предметов.
     */
    public boolean tryConsumeItemBudget() {
        if (!limitParticles.getValue()) return true;
        int limit = Math.round(particleLimit.getValue());
        return renderedItemsThisFrame.getAndIncrement() < limit;
    }

    // Очистка кэша рендера и частиц
    // Очистка кэша рендера и частиц
    private void clearRenderCaches() {
        try {
            if (mc.particleManager != null && mc.world != null) {
                // setWorld(...) публичный и внутри чистит все коллекции частиц
                mc.particleManager.setWorld(mc.world);
            }
        } catch (Throwable ignored) {}
    }

    // Принудительная работа с памятью.
    // force = true -> чистим сразу; иначе только если свободно < 20% кучи.
    private void forceMemoryCleanup(boolean force) {
        try {
            Runtime rt = Runtime.getRuntime();
            long free = rt.freeMemory();
            long total = rt.totalMemory();
            double freeRatio = (double) free / (double) total;
            if (force || freeRatio < 0.20) {
                System.gc();
            }
        } catch (Throwable ignored) {}
    }
}