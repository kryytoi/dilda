package dev.darkvisuals.modules.impl.utility;

import dev.darkvisuals.darkvisuals;
import dev.darkvisuals.client.ChatUtils;
import dev.darkvisuals.client.events.impl.EventPlayerTick;
import dev.darkvisuals.client.events.impl.EventRender3D;
import dev.darkvisuals.client.managers.ThemeManager;
import dev.darkvisuals.client.util.notify.Notify;
import dev.darkvisuals.client.util.notify.NotifyIcons;
import dev.darkvisuals.client.util.perf.Perf;
import dev.darkvisuals.client.util.renderer.Render3D;
import dev.darkvisuals.modules.api.Category;
import dev.darkvisuals.modules.api.Module;
import dev.darkvisuals.modules.settings.impl.BooleanSetting;
import lombok.Getter;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.awt.Color;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * RWHelper — набор помощников для сервера Really World.
 * <p>
 * 1. Не притягивать меня удочкой — полностью блокирует притягивание чужой удочкой
 *    (отмена пакета скорости через {@code AntiRodPullMixin} + тик-защита как запасной вариант).
 * 2. Защита от запрещённых слов — не даёт отправить сообщение с запрещённым словом.
 * 3. Радиус действия предметов — рисует радиус донатного предмета в руке.
 * 4. Уведомление при упоминании ника — пишет уведомление, если кто-то написал твой ник.
 */
public class RWHelper extends Module {

    @Getter
    private static RWHelper instance;

    @Getter
    private final BooleanSetting antiRodPull = new BooleanSetting("Не притягивать меня удочкой", true);
    @Getter
    private final BooleanSetting blockBadWords = new BooleanSetting("Защищать от запрещённых слов", true);
    @Getter
    private final BooleanSetting itemRadius = new BooleanSetting("Радиус действия предметов", true);
    @Getter
    private final BooleanSetting mentionNotify = new BooleanSetting("Уведомление при упоминании вашего ника", true);

    /** Запрещённые на Really World слова. */
    private static final List<String> BLOCKED_WORDS = List.of(
            "Юпитер", "Метеор", "Дельта", "Флюгер", "Целестиал",
            "Delta", "Celestial", "Fluger", "FlugerNew", "Целка",
            "Meteor", "Фантайм", "Funtime", "Нурик", "Нурсултан",
            "Nursultan", "Венус"
    );

    /** Донатные предметы и их радиус действия. */
    private static final Map<String, DonateItem> DONATE_ITEMS = new LinkedHashMap<>();

    static {
        // Ловушка (Heart of the Sea) — квадрат 6x6 с центром в игроке
        DONATE_ITEMS.put("ловушка", new DonateItem(Shape.SQUARE, 6.0f));
        // Шары (голова игрока) — круг радиусом N блоков на земле
        DONATE_ITEMS.put("шар хаоса", new DonateItem(Shape.CIRCLE, 8.0f));
        DONATE_ITEMS.put("шар света", new DonateItem(Shape.CIRCLE, 16.0f));
        // Остальные шары без заданного радиуса — просто известны клиенту
        DONATE_ITEMS.put("шар огня", new DonateItem(Shape.NONE, 0f));
        DONATE_ITEMS.put("шар воздуха", new DonateItem(Shape.NONE, 0f));
        DONATE_ITEMS.put("шар порядка", new DonateItem(Shape.NONE, 0f));
        DONATE_ITEMS.put("шар воды", new DonateItem(Shape.NONE, 0f));
        DONATE_ITEMS.put("шар земли", new DonateItem(Shape.NONE, 0f));
    }

    // --- анти-притягивание удочкой ---
    /** В каком радиусе чужой поплавок считается опасным (даже если хук ещё не синхронизирован). */
    private static final double HOOK_RANGE_SQ = 64.0D;  // 8 блоков вокруг игрока
    /** Сколько тиков после отмены пакета держим тик-защиту как запасной вариант. */
    private static final int PROTECT_TICKS = 15;
    private int protectTicks = 0;
    private Vec3d safeVelocity = Vec3d.ZERO;

    // --- уведомления об упоминании ---
    private static final long MENTION_COOLDOWN = 1500L;
    private long lastMention = 0L;

    // --- рендер радиуса ---
    private static final int CIRCLE_SEGMENTS = 72;
    private static final int SQUARE_ALPHA = (int) (255 * 0.35f); // 35% прозрачность

    public RWHelper() {
        super("RWHelper", Category.Utility, "Помощник для сервера Really World: защита от удочки, фильтр слов, радиусы донат-предметов и упоминания ника");
        instance = this;
        getSettings().add(antiRodPull);
        getSettings().add(blockBadWords);
        getSettings().add(itemRadius);
        getSettings().add(mentionNotify);
    }

    /* ------------------------------------------------------------------ */
    /* 1. Не притягивать меня удочкой                                      */
    /* ------------------------------------------------------------------ */

    /**
     * Проверяет, заблокировать ли пакет скорости.
     * Если персонаж получает урон (hurtTime > 0), пакет НЕ блокируется,
     * чтобы обычный отброс от атак работал штатно.
     */
    public boolean shouldCancelVelocityPacket(int entityId) {
        if (!antiRodPull.getValue()) return false;
        if (mc.player == null || mc.world == null) return false;
        if (entityId != mc.player.getId()) return false;

        // Если нас бьют прямо сейчас — пропускаем отброс!
        if (mc.player.hurtTime > 0) return false;

        // Блокируем ТОЛЬКО если рядом/на нас реально висит чужой поплавок
        if (!hasForeignBobberOnMe()) return false;

        protectTicks = PROTECT_TICKS;
        safeVelocity = mc.player.getVelocity();
        return true;
    }

    public boolean shouldCancelExplosionKnockback() {
        if (!antiRodPull.getValue()) return false;
        if (mc.player == null || mc.world == null) return false;
        if (mc.player.hurtTime > 0) return false;

        if (!hasForeignBobberOnMe()) return false;

        protectTicks = PROTECT_TICKS;
        safeVelocity = mc.player.getVelocity();
        return true;
    }

    public boolean shouldCancelPositionLookVelocity(net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket packet) {
        if (!antiRodPull.getValue()) return false;
        if (mc.player == null || mc.world == null) return false;
        if (mc.player.hurtTime > 0) return false;

        var relatives = packet.relatives();
        var change = packet.change();

        boolean posRelative = relatives.contains(net.minecraft.network.packet.s2c.play.PositionFlag.X)
                && relatives.contains(net.minecraft.network.packet.s2c.play.PositionFlag.Y)
                && relatives.contains(net.minecraft.network.packet.s2c.play.PositionFlag.Z);
        if (!posRelative) return false;

        Vec3d pos = change.position();
        if (Math.abs(pos.x) > 1.0E-4 || Math.abs(pos.y) > 1.0E-4 || Math.abs(pos.z) > 1.0E-4) {
            return false;
        }

        if (!hasForeignBobberOnMe()) return false;

        protectTicks = PROTECT_TICKS;
        safeVelocity = mc.player.getVelocity();
        return true;
    }

    /** Есть ли чужой поплавок, который зацепил нас или находится вплотную. */
    public boolean hasForeignBobberOnMe() {
        if (mc.player == null || mc.world == null) return false;
        ClientPlayerEntity player = mc.player;
        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof FishingBobberEntity bobber)) continue;
            PlayerEntity owner = bobber.getPlayerOwner();
            if (owner == null || owner == player) continue;

            if (bobber.getHookedEntity() == player) return true;
            if (bobber.squaredDistanceTo(player) <= HOOK_RANGE_SQ) return true;
        }
        return false;
    }

    /**
     * Запасная тик-защита.
     */
    @EventHandler
    public void onPlayerTick(EventPlayerTick e) {
        if (fullNullCheck()) return;
        if (!antiRodPull.getValue()) {
            protectTicks = 0;
            return;
        }

        ClientPlayerEntity player = mc.player;

        // Если игрока бьют (hurtTime > 0) — отключаем удерживание скорости,
        // чтобы отброс от меча/стрел проходил нормально
        if (player.hurtTime > 0) {
            protectTicks = 0;
            safeVelocity = player.getVelocity();
            return;
        }

        if (hasForeignBobberOnMe()) {
            protectTicks = PROTECT_TICKS;
            Vec3d velocity = player.getVelocity();
            double horizontal = Math.hypot(velocity.x, velocity.z);
            double safeHorizontal = Math.hypot(safeVelocity.x, safeVelocity.z);
            if (horizontal > safeHorizontal + 0.05D || velocity.y > safeVelocity.y + 0.05D) {
                player.setVelocity(safeVelocity.x, Math.min(velocity.y, safeVelocity.y), safeVelocity.z);
            } else {
                safeVelocity = velocity;
            }
            return;
        }

        if (protectTicks <= 0) {
            safeVelocity = player.getVelocity();
            return;
        }
        protectTicks--;

        Vec3d velocity = player.getVelocity();
        double horizontal = Math.hypot(velocity.x, velocity.z);
        double safeHorizontal = Math.hypot(safeVelocity.x, safeVelocity.z);

        if (horizontal > safeHorizontal + 0.05D || velocity.y > safeVelocity.y + 0.05D) {
            player.setVelocity(safeVelocity.x, Math.min(velocity.y, safeVelocity.y), safeVelocity.z);
        } else {
            safeVelocity = velocity;
        }
    }

    /* ------------------------------------------------------------------ */
    /* 2. Защита от запрещённых слов                                       */
    /* ------------------------------------------------------------------ */

    /**
     * Ищет запрещённое слово в сообщении.
     *
     * @return найденное слово или {@code null}, если сообщение чистое
     */
    public String findBlockedWord(String message) {
        if (message == null || message.isBlank()) return null;
        String lower = message.toLowerCase(Locale.ROOT);
        for (String word : BLOCKED_WORDS) {
            if (lower.contains(word.toLowerCase(Locale.ROOT))) return word;
        }
        return null;
    }

    /** Сообщает игроку, что слово запрещено, и что сообщение не ушло в чат. */
    public void notifyBlockedWord(String word) {
        ChatUtils.sendMessage("Слово \"" + word + "\" запрещено на сервере Really World, сообщение не отправлен��");
        addNotify("Слово \"" + word + "\" запрещено на Really World");
    }

    /* ------------------------------------------------------------------ */
    /* 3. Радиус действия предметов                                        */
    /* ------------------------------------------------------------------ */

    @EventHandler
    public void onRender3D(EventRender3D.Game e) {
        if (fullNullCheck()) return;
        if (!itemRadius.getValue()) return;

        try (var __ = Perf.scopeCpu("RWHelper.onRender3D")) {
            DonateItem item = getHeldDonateItem();
            if (item == null || item.shape() == Shape.NONE) return;

            Color theme = ThemeManager.getInstance().getCurrentTheme().getBackgroundColor();
            ClientPlayerEntity player = mc.player;
            float tickDelta = Render3D.getTickDelta();
            double x = player.prevX + (player.getX() - player.prevX) * tickDelta;
            double y = player.prevY + (player.getY() - player.prevY) * tickDelta;
            double z = player.prevZ + (player.getZ() - player.prevZ) * tickDelta;

            Render3D.prepare();
            if (item.shape() == Shape.SQUARE) {
                renderSquare(e, new Vec3d(x, y, z), item.size(), theme);
            } else {
                renderCircle(new Vec3d(x, y, z), item.size(), theme);
            }
            Render3D.render();
        }
    }

    /** Квадрат size x size с центром в игроке, прозрачность 35%. */
    private void renderSquare(EventRender3D.Game e, Vec3d center, float size, Color theme) {
        double half = size / 2.0D;
        Box box = new Box(
                center.x - half, center.y + 0.01D, center.z - half,
                center.x + half, center.y + 0.03D, center.z + half
        );
        Color fill = new Color(theme.getRed(), theme.getGreen(), theme.getBlue(), SQUARE_ALPHA);
        Color outline = new Color(theme.getRed(), theme.getGreen(), theme.getBlue(), 220);
        Render3D.renderBox(e.getMatrices(), box, fill);
        Render3D.renderBoxOutline(e.getMatrices(), box, outline);
    }

    /** Круг заданного радиуса на земле под игроком. */
    private void renderCircle(Vec3d center, float radius, Color theme) {
        int argb = new Color(theme.getRed(), theme.getGreen(), theme.getBlue(), 235).getRGB();
        Render3D.DEBUG_LINE_WIDTH = 2.0f;

        double y = center.y + 0.02D;
        Vec3d prev = null;
        for (int i = 0; i <= CIRCLE_SEGMENTS; i++) {
            double angle = (Math.PI * 2 * i) / CIRCLE_SEGMENTS;
            Vec3d point = new Vec3d(
                    center.x + Math.cos(angle) * radius,
                    y,
                    center.z + Math.sin(angle) * radius
            );
            if (prev != null) Render3D.drawLine(prev, point, argb, Render3D.DEBUG_LINE_WIDTH);
            prev = point;
        }
    }

    /** Донатный предмет в главной или второй руке, либо {@code null}. */
    private DonateItem getHeldDonateItem() {
        DonateItem main = resolveDonateItem(mc.player.getMainHandStack());
        if (main != null) return main;
        return resolveDonateItem(mc.player.getOffHandStack());
    }

    private DonateItem resolveDonateItem(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return null;
        String name = stripFormatting(stack.getName().getString()).toLowerCase(Locale.ROOT).trim();
        if (name.isEmpty()) return null;
        for (Map.Entry<String, DonateItem> entry : DONATE_ITEMS.entrySet()) {
            if (name.contains(entry.getKey())) return entry.getValue();
        }
        return null;
    }

    /* ------------------------------------------------------------------ */
    /* 4. Уведомление при упоминании ника                                  */
    /* ------------------------------------------------------------------ */

    /**
     * Проверяет входящее сообщение чата на упоминание ника игрока.
     * Вызывается из {@code ChatHudNameProtectMixin}.
     */
    public void handleIncomingMessage(String raw) {
        if (!mentionNotify.getValue()) return;
        if (raw == null || raw.isBlank()) return;
        if (mc.getSession() == null) return;

        String self = mc.getSession().getUsername();
        if (self == null || self.isBlank()) return;

        String message = stripFormatting(raw);
        String sender = parseSender(message);
        // Своё же сообщение игнорируем
        if (sender != null && sender.equalsIgnoreCase(self)) return;

        // Ник должен быть именно в тексте сообщения, а не в имени отправителя
        String body = sender != null ? message.substring(message.indexOf(sender) + sender.length()) : message;
        if (!containsWord(body, self)) return;

        long now = System.currentTimeMillis();
        if (now - lastMention < MENTION_COOLDOWN) return;
        lastMention = now;

        String who = sender != null ? sender : "Кто-то";
        addNotify("[" + who + "] Написал ваш ник!");
        ChatUtils.sendMessage("[" + who + "] Написал ваш ник!");
    }

    /** Пытается вытащить ник отправителя из строки чата: "[Ник] текст" или "Ник: текст". */
    private String parseSender(String message) {
        int colon = message.indexOf(':');
        int bracketOpen = message.indexOf('<');
        int bracketClose = message.indexOf('>');

        if (bracketOpen >= 0 && bracketClose > bracketOpen) {
            String candidate = message.substring(bracketOpen + 1, bracketClose).trim();
            if (isNickLike(candidate)) return candidate;
        }
        if (colon > 0) {
            String head = message.substring(0, colon);
            String[] parts = head.split("[\\s\\[\\]|»→⇨]+");
            for (int i = parts.length - 1; i >= 0; i--) {
                String candidate = parts[i].trim();
                if (isNickLike(candidate)) return candidate;
            }
        }
        return null;
    }

    private boolean isNickLike(String value) {
        if (value.length() < 3 || value.length() > 16) return false;
        for (char c : value.toCharArray()) {
            if (!Character.isLetterOrDigit(c) && c != '_') return false;
        }
        return true;
    }

    private boolean containsWord(String text, String word) {
        String lowerText = text.toLowerCase(Locale.ROOT);
        String lowerWord = word.toLowerCase(Locale.ROOT);
        int index = lowerText.indexOf(lowerWord);
        while (index >= 0) {
            int end = index + lowerWord.length();
            boolean leftOk = index == 0 || !isNickChar(lowerText.charAt(index - 1));
            boolean rightOk = end >= lowerText.length() || !isNickChar(lowerText.charAt(end));
            if (leftOk && rightOk) return true;
            index = lowerText.indexOf(lowerWord, index + 1);
        }
        return false;
    }

    private boolean isNickChar(char c) {
        return Character.isLetterOrDigit(c) || c == '_';
    }

    /* ------------------------------------------------------------------ */
    /* Утилиты                                                             */
    /* ------------------------------------------------------------------ */

    private void addNotify(String text) {
        try {
            darkvisuals.getInstance().getNotifyManager().add(new Notify(NotifyIcons.dangerIcon, text, 2500));
        } catch (Throwable ignored) {}
    }

    private static String stripFormatting(String input) {
        return input.replaceAll("§.", "");
    }

    private enum Shape {
        NONE, CIRCLE, SQUARE
    }

    private record DonateItem(Shape shape, float size) {}
}
