package dev.darkvisuals.modules.impl.utility;

import dev.darkvisuals.client.managers.UserTabManager;
import dev.darkvisuals.modules.api.Category;
import dev.darkvisuals.modules.api.Module;
import dev.darkvisuals.modules.settings.impl.BooleanSetting;
import lombok.Getter;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.Optional;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * Показывает значок клиента рядом с ником игроков, которые используют DarkVisuals.
 * Определение полностью автоматическое (см. {@link UserTabManager}) — модуль сам
 * знает, у кого стоит клиент, никакого ручного списка нет. Единственное исключение —
 * вы сами: свой ник всегда считается "пользователем DarkVisuals", ведь клиент у вас
 * точно установлен.
 * <p>
 * Значок рисуется через кастомный vanilla-шрифт "darkvisuals:user_tab"
 * (assets/darkvisuals/font/user_tab.json), поэтому одна и та же проверка работает
 * и над головой игрока, и в tab-листе.
 * <p>
 * ВАЖНО для серверов вроде ReallyWorld: неймтеги там рисуются TextDisplay-сущностями
 * и содержат legacy-коды форматирования (§a, §l, ...), PUA-глифы серверного
 * ресурспака (донатные значки, логотипы) и статистику ("20 ❤"). Поэтому перед
 * поиском ника входной текст ОБЯЗАТЕЛЬНО прогоняется через
 * {@link #sanitizeForNameSearch(String)} — иначе ник внутри строки не находится.
 */
public class UserTab extends Module {

    @Getter
    private static UserTab instance;

    @Getter
    private final BooleanSetting showInTab = new BooleanSetting("Значок в табе", true);

    @Getter
    private final BooleanSetting showAboveHead = new BooleanSetting("Значок над головой", true);

    @Getter
    private final BooleanSetting showSelf = new BooleanSetting("Показывать себя", true);

    /** Показывать себя в табе, даже если сервер скрыл запись (listed=false). */
    @Getter
    private final BooleanSetting showSelfInList = new BooleanSetting("Я в табе", true);

    /** Убирать квадраты (PUA-глифы серверного ресурспака) из своего ника в табе. */
    @Getter
    private final BooleanSetting cleanOwnName = new BooleanSetting("Убирать квадраты", true);

    // ---------------------------------------------------------------------
    // Предкомпилированные паттерны: containsDarkVisualsUser вызывается каждый
    // кадр для каждого неймтега, компилировать regex на лету нельзя.
    // ---------------------------------------------------------------------

    /** Legacy-коды форматирования: §a, §l, §x и т.д. (любой символ после §). */
    private static final Pattern LEGACY_FORMATTING = Pattern.compile("§.");

    /**
     * PUA-символы: BMP (U+E000–U+F8FF), дополнительные плоскости 15–16
     * (U+F0000–U+FFFFD, U+100000–U+10FFFD) и replacement char (U+FFFD).
     * Это глифы серверных ресурспаков — донатные значки, логотипы, сердечки HP.
     */
    private static final Pattern PUA_GLYPHS =
            Pattern.compile("[\\uE000-\\uF8FF\\uFFFD\\x{F0000}-\\x{FFFFD}\\x{100000}-\\x{10FFFD}]");

    /**
     * Всё, что не может входить в ник Minecraft (буквы/цифры/подчёркивание),
     * заменяем пробелом: скобки префиксов "[MAGISTER]", символы "❤", "|", ":"
     * и прочие значки превращаются в границы слов.
     */
    private static final Pattern NON_NAME_CHARS = Pattern.compile("[^\\p{L}\\p{N}_]+");

    private static final Pattern MULTI_SPACE = Pattern.compile(" {2,}");

    public UserTab() {
        super("UserTab", Category.Utility, "Показывает значок клиента рядом с ником игроков, использующих DarkVisuals");
        getSettings().add(showInTab);
        getSettings().add(showAboveHead);
        getSettings().add(showSelf);
        getSettings().add(showSelfInList);
        getSettings().add(cleanOwnName);
        instance = this;

        UserTabManager.init();
    }

    /** Проверка по UUID — используется в tab-листе, где UUID есть напрямую из PlayerListEntry. */
    public boolean isDarkVisualsUser(UUID uuid) {
        if (!isToggled() || uuid == null) return false;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (showSelf.getValue() && mc.player != null && uuid.equals(mc.player.getUuid())) {
            return true;
        }

        return UserTabManager.isKnownUser(uuid);
    }

    /**
     * Очищает сырую строку неймтега перед поиском ника:
     * <ol>
     *     <li>Убирает legacy-коды форматирования ({@code §.}).</li>
     *     <li>Убирает PUA-глифы серверного ресурспака (U+E000–U+F8FF,
     *     плоскости 15–16) и U+FFFD.</li>
     *     <li>Заменяет все символы, не входящие в допустимый алфавит ников
     *     (буквы, цифры, {@code _}), на пробелы — так "[MAGISTER]", "20 ❤",
     *     разделители и переносы строк становятся границами слов.</li>
     *     <li>Схлопывает повторные пробелы и обрезает края.</li>
     * </ol>
     * После этого строка вида
     * {@code "§c[MAGISTER] §fNick_123\n§a20 ❤"} превращается в
     * {@code "MAGISTER Nick_123 20"} — ник находится стабильно.
     */
    public static String sanitizeForNameSearch(String text) {
        if (text == null || text.isEmpty()) return "";
        String cleaned = LEGACY_FORMATTING.matcher(text).replaceAll("");
        cleaned = PUA_GLYPHS.matcher(cleaned).replaceAll(" ");
        cleaned = NON_NAME_CHARS.matcher(cleaned).replaceAll(" ");
        cleaned = MULTI_SPACE.matcher(cleaned).replaceAll(" ");
        return cleaned.trim();
    }

    /**
     * Проверка по тексту ника (для рендера над головой, где напрямую UUID недоступен) —
     * ищет игрока в текущем tab-листе по имени и сверяет его UUID автоматически.
     * Входной текст предварительно очищается через {@link #sanitizeForNameSearch(String)},
     * поэтому §-коды, PUA-значки и статистика ("20 ❤") поиску не мешают.
     */
    public boolean containsDarkVisualsUser(String text) {
        return findDarkVisualsUserName(text) != null;
    }

    /**
     * То же, что {@link #containsDarkVisualsUser(String)}, но возвращает
     * найденный ник пользователя DarkVisuals (или {@code null}) — нужно
     * миксину TextDisplay, чтобы вставить значок именно перед ником.
     */
    public String findDarkVisualsUserName(String text) {
        if (!isToggled() || text == null || text.isEmpty()) return null;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() == null) return null;

        String sanitized = sanitizeForNameSearch(text);
        if (sanitized.isEmpty()) return null;

        for (PlayerListEntry entry : mc.getNetworkHandler().getPlayerList()) {
            String name = entry.getProfile().getName();
            if (name == null || name.isEmpty()) continue;
            if (!containsWord(sanitized, name)) continue;
            if (isDarkVisualsUser(entry.getProfile().getId())) return name;
        }

        return null;
    }

    /**
     * Ищет ник как отдельное "слово". Границей считается любой символ,
     * который не может входить в ник ({@code [^a-zA-Z0-9_]}) — подчёркивание
     * НЕ граница, иначе "Nick" ложно находился бы внутри "Nick_123".
     */
    private boolean containsWord(String text, String name) {
        String lowerText = text.toLowerCase();
        String lowerName = name.toLowerCase();

        int idx = -1;
        while ((idx = lowerText.indexOf(lowerName, idx + 1)) != -1) {
            boolean leftOk = idx == 0 || isBoundary(text.charAt(idx - 1));
            int end = idx + name.length();
            boolean rightOk = end >= text.length() || isBoundary(text.charAt(end));
            if (leftOk && rightOk) return true;
        }
        return false;
    }

    private static boolean isBoundary(char c) {
        return !Character.isLetterOrDigit(c) && c != '_';
    }

    /**
     * Проверяет, содержит ли Text уже значок DarkVisuals (сегмент со шрифтом
     * из namespace "darkvisuals"). Нужна мьютексам как защита от повторного
     * добавления значка: getLines/renderLabelIfPresent вызываются каждый кадр.
     */
    public boolean hasBadge(Text text) {
        if (text == null) return false;
        return text.visit((style, str) -> {
            Identifier font = style.getFont();
            if (font != null && "darkvisuals".equals(font.getNamespace())) {
                return Optional.of(Boolean.TRUE);
            }
            return Optional.empty();
        }, Style.EMPTY).isPresent();
    }

    /**
     * Вычищает из текста PUA-символы (U+E000–U+F8FF и дополнительные плоскости
     * 15–16) — глифы серверного кастомного шрифта, которые без ресурспака
     * рендерятся квадратами, — а также U+FFFD.
     * <p>
     * ВАЖНО: сегменты со шрифтами из пространства имён "darkvisuals" (например,
     * значок user_tab) не трогаются — иначе чистка удалила бы наш же значок.
     * Стили (цвета, жирность) остальных сегментов сохраняются.
     */
    public Text stripServerGlyphs(Text text) {
        MutableText result = Text.empty();
        text.visit((style, str) -> {
            Identifier font = style.getFont();
            // Наши собственные шрифты (значок DarkVisuals) оставляем как есть
            if (font != null && "darkvisuals".equals(font.getNamespace())) {
                result.append(Text.literal(str).setStyle(style));
                return Optional.empty();
            }
            String cleaned = PUA_GLYPHS.matcher(str).replaceAll("");
            cleaned = MULTI_SPACE.matcher(cleaned).replaceAll(" ");
            if (!cleaned.isEmpty()) {
                result.append(Text.literal(cleaned).setStyle(style));
            }
            return Optional.empty();
        }, Style.EMPTY);
        return result;
    }
}
