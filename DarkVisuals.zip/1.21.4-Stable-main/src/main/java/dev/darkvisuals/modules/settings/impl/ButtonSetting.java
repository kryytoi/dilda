package dev.darkvisuals.modules.settings.impl;

import dev.darkvisuals.modules.settings.Setting;

/**
 * Настройка-кнопка. Не хранит полезного значения, а выполняет действие
 * (Runnable) при нажатии в ClickGUI. Используется, например, у ViewModel
 * для кнопки "Настроить".
 */
public class ButtonSetting extends Setting<Boolean> {

    private final Runnable action;

    public ButtonSetting(String name, Runnable action) {
        super(name, false);
        this.action = action;
    }

    /** Выполнить действие кнопки (вызывается из ButtonComponent при клике). */
    public void click() {
        if (action != null) action.run();
    }
}
